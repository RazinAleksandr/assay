"""App profile (assay.yaml) and suite loading.

The profile is the only product-specific part. For most apps it is pure config:
how to start the app, how to log in, where state lives (probes), what to ignore.
Code plugins are optional (custom steps / probes / checks).
"""
from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from .model import Case

DEFAULT_VIEWPORTS = {
    "desktop": {"width": 1366, "height": 860},
    "mobile": {"device": "iPhone 13"},
}

DEFAULT_GATE = {
    "fail_on_case_fail": True,          # any must-FAIL case blocks the release
    "max_new": {"blocker": 0, "critical": 0},
    "min_rating": {},                   # e.g. {reliability: B, accessibility: C}
    "max_inconclusive": 0.2,            # above this share the gate is INCONCLUSIVE, not PASS
}


@dataclass
class Profile:
    name: str
    root: Path
    base_url: str
    title: str = ""
    kind: str = "web"
    app: dict = field(default_factory=dict)
    accounts: dict = field(default_factory=dict)
    auth: dict = field(default_factory=dict)
    probes: dict = field(default_factory=dict)
    volatile: list[str] = field(default_factory=list)
    sensors: dict = field(default_factory=dict)
    ignore: dict = field(default_factory=dict)
    viewports: dict = field(default_factory=lambda: dict(DEFAULT_VIEWPORTS))
    judge: dict = field(default_factory=dict)
    gate: dict = field(default_factory=lambda: dict(DEFAULT_GATE))
    scan: dict = field(default_factory=dict)
    chat: dict = field(default_factory=dict)
    agent: dict = field(default_factory=dict)
    browser: dict = field(default_factory=dict)
    suites: list[str] = field(default_factory=list)
    plugins: list[str] = field(default_factory=list)
    env: dict = field(default_factory=dict)
    raw: dict = field(default_factory=dict)

    def sensor_on(self, name: str) -> bool:
        v = self.sensors.get(name, True)
        return bool(v) if not isinstance(v, dict) else v.get("enabled", True)

    def url(self, path: str) -> str:
        if re.match(r"^[a-z]+://", path):
            return path
        return self.base_url.rstrip("/") + "/" + path.lstrip("/")


def _expand(value: Any, ctx: dict) -> Any:
    """Expand {env.X}, {root}, {account.x} and friends inside strings, recursively."""
    if isinstance(value, str):
        def repl(m: re.Match) -> str:
            key = m.group(1)
            cur: Any = ctx
            for part in key.split("."):
                if isinstance(cur, dict) and part in cur:
                    cur = cur[part]
                else:
                    return m.group(0)
            return str(cur)
        return re.sub(r"\{([a-zA-Z_][\w.]*)\}", repl, value)
    if isinstance(value, list):
        return [_expand(v, ctx) for v in value]
    if isinstance(value, dict):
        return {k: _expand(v, ctx) for k, v in value.items()}
    return value


def expand(value: Any, profile: Profile, **extra: Any) -> Any:
    ctx = {"env": {**os.environ, **profile.env}, "root": str(profile.root),
           "base_url": profile.base_url, "origin": _origin(profile.base_url), **extra}
    return _expand(value, ctx)


def _origin(url: str) -> str:
    m = re.match(r"^([a-z]+://[^/]+)", url or "")
    return m.group(1) if m else url


def load_profile(path: str | Path) -> Profile:
    path = Path(path)
    if path.is_dir():
        path = path / "assay.yaml"
    raw = yaml.safe_load(path.read_text()) or {}
    root = path.parent.resolve()
    env = {k: str(v) for k, v in (raw.get("env") or {}).items()}
    # env values may reference {root}
    env = {k: v.replace("{root}", str(root)) for k, v in env.items()}
    gate = dict(DEFAULT_GATE)
    gate.update(raw.get("gate") or {})
    viewports = dict(DEFAULT_VIEWPORTS)
    viewports.update(raw.get("viewports") or {})
    prof = Profile(
        name=raw.get("name") or root.name, root=root, base_url=raw["base_url"],
        title=raw.get("title", ""), kind=raw.get("kind", "web"), app=raw.get("app") or {},
        accounts=raw.get("accounts") or {}, auth=raw.get("auth") or {}, probes=raw.get("probes") or {},
        volatile=list(raw.get("volatile") or []), sensors=raw.get("sensors") or {},
        ignore=raw.get("ignore") or {}, viewports=viewports, judge=raw.get("judge") or {},
        gate=gate, scan=raw.get("scan") or {}, chat=raw.get("chat") or {}, agent=raw.get("agent") or {},
        browser=raw.get("browser") or {}, suites=list(raw.get("suites") or ["cases"]),
        plugins=list(raw.get("plugins") or []), env=env, raw=raw,
    )
    prof.base_url = expand(prof.base_url, prof)
    from .rules import set_route_patterns
    set_route_patterns(prof.scan.get("route_patterns"))
    return prof


def load_cases(profile: Profile, selectors: list[str] | None = None) -> list[Case]:
    """Load every case from the profile's suites (YAML or JSON, a list or {cases: [...]}). A journey's group is its file
    inside the suite without the extension (cases/social/feed.yaml → social/feed) unless it names one."""
    files: list[tuple[Path, Path]] = []                  # (file, the folder its group is relative to)
    for s in profile.suites:
        p = (profile.root / s)
        if p.is_dir():
            files += [(x, p) for x in sorted(p.rglob("*")) if x.suffix in (".yaml", ".yml", ".json")]
        elif p.exists():
            files.append((p, p.parent))
    cases: list[Case] = []
    seen: set[str] = set()
    for f, base in files:
        data = json.loads(f.read_text()) if f.suffix == ".json" else yaml.safe_load(f.read_text())
        if isinstance(data, dict):
            data = data.get("cases", [])
        for d in data or []:
            c = Case.from_dict(d, source=str(f.relative_to(profile.root)), group=f.relative_to(base).with_suffix("").as_posix())
            if c.id in seen:
                raise ValueError(f"duplicate case id {c.id!r} in {f}")
            seen.add(c.id)
            cases.append(c)
    if selectors:
        cases = [c for c in cases if any(_select(c, s) for s in selectors)]
    return cases


def _select(case: Case, sel: str) -> bool:
    """`-k` selectors: a glob on the id, `tag:<name>`, `group:<glob>` (`group:social/*`), `is:critical` or `is:ai`."""
    import fnmatch
    if sel.startswith("tag:"):
        return sel[4:] in case.tags
    if sel.startswith("group:"):
        return fnmatch.fnmatchcase(case.group, sel[6:])
    if sel in ("is:critical", "is:ai"):
        return bool(getattr(case, sel[3:]))
    return fnmatch.fnmatch(case.id, sel)


def load_plugins(profile: Profile) -> list[str]:
    """Import plugin modules (dotted names or .py paths relative to the project) that register steps/checks."""
    import importlib
    import importlib.util
    loaded = []
    for ref in profile.plugins:
        if ref.endswith(".py"):
            path = (profile.root / ref).resolve()
            spec = importlib.util.spec_from_file_location(f"assay_plugin_{path.stem}", path)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
        else:
            mod = importlib.import_module(ref)
        if hasattr(mod, "register"):
            mod.register(profile)
        loaded.append(ref)
    return loaded
