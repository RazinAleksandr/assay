"""Pages of the Assay server. Every page is rendered on the server from the analyses CI uploaded."""
from __future__ import annotations

import json
import threading
from collections import Counter, OrderedDict
from dataclasses import dataclass, field
from datetime import datetime
from urllib.parse import urlencode

from ..rules import RULES
from .ui import (DIM_HELP, purl, repo_name, DIM_SHORT, SEV_ORDER, ago, avatar, dim_sev, donut, e, gate, icon, line_chart, local, page_head, rating,
                 sev, shell, verdict, when)

_CACHE: "OrderedDict[tuple, dict]" = OrderedDict()
_CACHE_LOCK = threading.Lock()


def analysis(store, aid: int) -> dict | None:
    """Analyses never change once uploaded: keep the last few parsed (per data folder; pages render in many threads)."""
    k = (str(store.root), aid)
    with _CACHE_LOCK:
        if k in _CACHE:
            _CACHE.move_to_end(k)
            return _CACHE[k]
    a = store.analysis(aid)
    if a is not None:
        with _CACHE_LOCK:
            _CACHE[k] = a
            while len(_CACHE) > 48:
                _CACHE.popitem(last=False)
    return a


def _dt(iso: str | None) -> datetime | None:
    """Uploads may carry any `created` string: a bad one hides that point, never the page."""
    return local(iso)


def _fmt(iso: str | None, f: str, missing: str = "—") -> str:
    d = _dt(iso)
    return d.strftime(f) if d else missing


def evidence(store, aid: int, case_id: str) -> dict:
    f = store.dir(aid) / "cases" / case_id / "evidence.json"
    try:
        return json.loads(f.read_text())
    except Exception:
        return {}


# ---- context: which project, which branch / pull request, which analysis -------------------------------------------------

@dataclass
class Ctx:
    store: object
    p: object
    rows: list
    row: object | None
    a: dict | None
    branch: str | None
    pr: str | None
    explicit: bool = False
    public: str = ""
    q: dict = field(default_factory=dict)
    benches: list = field(default_factory=list)

    @property
    def key(self) -> str:
        return self.p["key"]

    def qs(self, latest: bool = False, **extra) -> str:
        d = {"pr": self.pr} if self.pr else ({"branch": self.branch} if self.branch else {})
        if self.explicit and self.row and not latest:
            d["analysis"] = self.row["id"]
        d.update({k: v for k, v in extra.items() if v is not None})
        return "?" + urlencode(d)

    def url(self, page: str = "", latest: bool = False, **extra) -> str:
        return f"{purl(self.key)}{('/' + page) if page else ''}{self.qs(latest, **extra)}"

    def history(self) -> list:
        """Analyses of the same branch or pull request, oldest first."""
        if self.pr:
            return [r for r in reversed(self.rows) if r["pr"] == self.pr]
        return [r for r in reversed(self.rows) if not r["pr"] and r["branch"] == self.branch]

    @property
    def ref(self):
        return self.store.row(self.row["reference_id"]) if self.row and self.row["reference_id"] else None


def resolve(store, key: str, q: dict, public: str = "") -> Ctx | None:
    with store.db() as c:
        p = c.execute("select * from projects where key=?", (key,)).fetchone()
        if not p:
            return None
        rows = c.execute("select * from analyses where project=? order by created desc, id desc", (key,)).fetchall()
    row, explicit = None, False
    if q.get("analysis"):
        try:
            row = store.row(int(q["analysis"]))
            explicit = bool(row and row["project"] == key)
            row = row if explicit else None
        except ValueError:
            row = None
    if row is None and q.get("pr"):
        row = store.latest(key, pr=q["pr"])
    if row is None and not q.get("pr"):
        row = store.latest(key, branch=q.get("branch") or p["default_branch"])
    pr = row["pr"] if row else q.get("pr")
    branch = row["branch"] if row else (q.get("branch") or p["default_branch"])
    with store.db() as c:
        benches = c.execute("select * from benchmarks where project=? order by created desc, id desc", (key,)).fetchall()
    return Ctx(store, p, rows, row, analysis(store, row["id"]) if row else None, branch, pr, explicit, public, q, benches)


# ---- shared project chrome --------------------------------------------------------------------------------------------

def base_crumbs(p) -> list:
    """GitHub projects sit under their owner's account, legacy projects under the project list."""
    k = p["key"]
    if k.startswith("gh/"):
        owner = k.split("/")[1]
        return [(owner, f"/gh/{owner}"), (p["title"], purl(k))]
    return [("Projects", "/projects"), (p["title"], purl(k))]


def snav(ctx: Ctx, active: str) -> str:
    a = ctx.a or {}
    prs = len({r["pr"] for r in ctx.rows if r["pr"]})
    branches = len({r["branch"] for r in ctx.rows if not r["pr"]})
    items = [("summary", "", "overview", "Summary", None),
             ("issues", "issues", "issues", "Issues", len(a.get("issues", [])) if a else None),
             ("journeys", "journeys", "journey", "Journeys", len(a.get("cases", [])) if a else None),
             ("screens", "screens", "screens", "Screens", len(a.get("pages", [])) if a else None),
             ("activity", "activity", "activity", "Activity", None)]
    if ctx.benches:                                  # products with AI: the benchmark workflow's results
        items.append(("bench", "benchmarks", "flask", "Benchmarks", len(ctx.benches)))
    proj = [("prs", "pull-requests", "pr", "Pull requests", prs), ("branches", "branches", "branch", "Branches", branches),
            ("gate", "quality-gate", "gate", "Quality gate", None), ("setup", "setup", "setup", "Set up CI", None)]

    def link(k, page, ic, label, n):
        href = ctx.url(page) if k in ("summary", "issues", "journeys", "screens", "activity") else f"{purl(ctx.key)}/{page}"
        return (f'<a class="it{" on" if active == k else ""}" href="{e(href)}">{icon(ic)}{label}'
                f'{f"<span class=cnt>{n}</span>" if n is not None else ""}</a>')
    return (f'<aside class=snav aria-label="Project"><div class=proj>{avatar(ctx.key, ctx.p["title"])}<div><b>{e(ctx.p["title"])}</b>'
            f'<span class=mono title="{e(repo_name(ctx.key))}">{e(ctx.key.split("/")[-1])}</span></div></div>'
            + "".join(link(*i) for i in items) + '<div class=grp>Project</div>' + "".join(link(*i) for i in proj) + '</aside>')


def scope_selector(ctx: Ctx, page: str) -> str:
    base = f"{purl(ctx.key)}{('/' + page) if page else ''}"
    branches = OrderedDict()
    prs = OrderedDict()
    for r in ctx.rows:            # newest first: first seen = latest
        if r["pr"]:
            prs.setdefault(r["pr"], r)
        else:
            branches.setdefault(r["branch"], r)
    cur = (f'{icon("pr")}<span>#{e(ctx.pr)}</span>' if ctx.pr else f'{icon("branch")}<span>{e(ctx.branch)}</span>')
    items = ['<div class=mh>Branches</div>']
    for b, r in sorted(branches.items(), key=lambda kv: (kv[0] != ctx.p["default_branch"], kv[0] or "")):
        on = not ctx.pr and b == ctx.branch
        items.append(f'<a class="{"on" if on else ""}" href="{e(base)}?{urlencode({"branch": b or ""})}">{icon("branch")}'
                     f'<span>{e(b or "(no branch)")}<span class=sub>{"Main branch · " if b == ctx.p["default_branch"] else ""}{ago(r["created"])}</span></span>'
                     f'<span class=r>{gate(r["status"], label=False)}</span></a>')
    if prs:
        items.append('<div class=mh>Pull requests</div>')
        for n, r in prs.items():
            on = ctx.pr == n
            items.append(f'<a class="{"on" if on else ""}" href="{e(base)}?{urlencode({"pr": n})}">{icon("pr")}'
                         f'<span>#{e(n)} {e(r["pr_title"] or "")}<span class=sub>{e(r["branch"])} → {e(r["target"])}</span></span>'
                         f'<span class=r>{gate(r["status"], label=False)}</span></a>')
    return f'<details class=sel><summary>{cur}{icon("down")}</summary><div class=menu>{"".join(items)}</div></details>'


def project_head(ctx: Ctx, title: str, page: str) -> str:
    r = ctx.row
    extra = scope_selector(ctx, page) + (gate(r["status"], label=False) if r else "")
    right = (f'<a class=btn href="{e(r["ci_url"])}" target=_blank rel=noopener>{icon("external")}CI run</a>' if r and r["ci_url"] else "")
    meta = []
    if r:
        if r["pr"]:
            meta.append(f'{icon("pr")} Pull request #{e(r["pr"])} <span class=ink>{e(r["pr_title"] or "")}</span> · '
                        f'<span class=mono>{e(r["branch"])} → {e(r["target"])}</span>')
        meta.append(f'Last analysis <span class=ink title="{e(when(r["created"]))}">{ago(r["created"])}</span>')
        if r["sha"]:
            meta.append(f'{icon("commit")} <span class=mono>{e(r["sha"][:7])}</span>')
        a = ctx.a or {}
        s = a.get("summary", {})
        meta.append(f'{s.get("cases", 0)} journeys · {s.get("pages_scanned", 0)} screens')
        latest = ctx.history()[-1] if ctx.history() else None
        if ctx.explicit and latest and latest["id"] != r["id"]:
            meta.append(f'<span class="chip warn">Older analysis #{r["id"]}</span> <a href="{e(ctx.url(page, latest=True))}">latest</a>')
        else:
            meta.append(f'Analysis #{r["id"]}')
    crumbs = [*base_crumbs(ctx.p), (title, None)]
    return page_head(crumbs, title, extra=extra, right=right, meta=meta)


def no_analysis(ctx: Ctx, title: str, page: str) -> str:
    body = project_head(ctx, title, page) + '<div class=page><div class="panel empty">No analysis on this branch yet. ' \
        'Push to it with the Assay step in CI, or pick another branch.</div></div>'
    return shell(f"{title} · {ctx.p['title']}", body, active="projects", snav=snav(ctx, page or "summary"))


def _new_code(ctx: Ctx) -> bool:
    return bool((ctx.a or {}).get("baseline"))


# ---- projects ------------------------------------------------------------------------------------------------------------------

def _latest_by_project(projects, allrows):
    """From analyses sorted newest first: each project's latest main-branch analysis, latest analysis of any kind, PR numbers."""
    default = {p["key"]: p["default_branch"] for p in projects}
    mains, lasts, prs = {}, {}, {}
    for r in allrows:
        k = r["project"]
        lasts.setdefault(k, r)
        if r["pr"]:
            prs.setdefault(k, set()).add(r["pr"])
        elif r["branch"] == default.get(k):
            mains.setdefault(k, r)
    return mains, lasts, prs


def visible(store, viewer, owner: str | None = None) -> tuple[list, list]:
    """Projects this viewer may see (and their analyses, newest first); optionally of one account."""
    with store.db() as c:
        projects = [p for p in c.execute("select * from projects order by title").fetchall()
                    if (viewer is None or viewer.can_view(p)) and (owner is None or p["owner"] == owner)]
        keys = {p["key"] for p in projects}
        allrows = [r for r in c.execute("select * from analyses order by created desc, id desc").fetchall() if r["project"] in keys]
    return projects, allrows


def project_cards(store, projects, allrows) -> tuple[list, Counter, dict]:
    mains, lasts, pr_sets = _latest_by_project(projects, allrows)
    cards, gates, rat = [], Counter(), {d: Counter() for d in ("functional", "reliability", "accessibility", "performance")}
    for p in projects:
        last = lasts.get(p["key"])
        main = mains.get(p["key"]) or last          # no analysis of the main branch yet: show the latest one
        a = analysis(store, main["id"]) if main else None
        prs = len(pr_sets.get(p["key"], ()))
        st = main["status"] if main else "none"
        scope = "" if not main or main is mains.get(p["key"]) else (
            f' · latest is <b>{"pull request #" + e(main["pr"]) if main["pr"] else e(main["branch"])}</b>')
        gates[st] += 1
        ratings = (a or {}).get("ratings", {})
        dims = (a or {}).get("dimensions", {})
        for d in rat:
            rat[d][ratings.get(d, "A")] += 1
        s = (a or {}).get("summary", {})
        cov = ((a or {}).get("coverage") or {}).get("ratio")
        rows = "".join(f'<div class=mrow><span class=l>{e(DIM_SHORT[d])}</span><span class=v>{dims.get(d, {}).get("issues", 0)}</span>{rating(ratings.get(d), "sm")}</div>'
                       for d in DIM_SHORT)
        pass_frac = (s["PASS"] / s["cases"]) if s.get("cases") else None
        attrs = " ".join(f'data-{d}="{ratings.get(d, "A")}"' for d in rat)
        lock = (f'<span class="chip" title="Visible to people with the link from the repository">{icon("lock")}Private</span>'
                if (p["visibility"] or "public") == "private" else "")
        cards.append(
            f'<article class=pcard data-item data-gate="{e(st)}" {attrs} data-name="{e(p["title"].lower())}" '
            f'data-issues="{s.get("issues", 0)}" data-last="{e((last or {"created": ""})["created"].replace("-", "").replace(":", "").replace("T", ""))}" '
            f'data-text="{e((p["title"] + " " + p["key"]).lower())}">'
            f'<div class=hd>{avatar(p["key"], p["title"], lg=True)}<div class=nm><a href="{e(purl(p["key"]))}">{e(p["title"])}</a>'
            f'<span>{e(repo_name(p["key"], p["key"]))} {lock}</span></div>{gate(st)}</div>'
            f'<div class=info><b>{s.get("cases", 0)}</b> journeys · <b>{s.get("pages_scanned", 0)}</b> screens · last analysis '
            f'<b>{ago(last["created"]) if last else "—"}</b>{scope}</div>'
            f'<div class=mrow><span class=l>Journeys passing</span><span class=v>{s.get("PASS", 0)}/{s.get("cases", 0)}</span>{donut(pass_frac, 22)}</div>'
            f'{rows}'
            f'<div class=mrow><span class=l>Screens covered by journeys</span><span class=v>{"—" if cov is None else f"{cov:.0%}"}</span>{donut(cov, 22)}</div>'
            f'<div class=ft><a href="{e(purl(p["key"]))}/pull-requests">{icon("pr")} {prs} pull request{"s" if prs != 1 else ""}</a>'
            f'<a href="{e(purl(p["key"]))}/branches">{icon("branch")} {e(p["default_branch"])}</a></div></article>')
    return cards, gates, rat


def projects_page(store, q: dict, viewer=None) -> str:
    projects, allrows = visible(store, viewer)
    query = (q.get("q") or "").strip()
    cards, gates, rat = project_cards(store, projects, allrows)

    def facet(name, label, values):
        btns = "".join(f'<button type=button data-facet="{name}" data-value="{v}">{lab}<span class=n>{n}</span></button>' for v, lab, n in values)
        return f'<div class=facet><h4>{e(label)}</h4>{btns}</div>'
    fac = [facet("gate", "Quality gate", [(k, gate(k), gates.get(k, 0)) for k in ("PASSED", "FAILED", "INCONCLUSIVE")])]
    for d, cnt in rat.items():
        total = max(1, sum(cnt.values()))
        fac.append(facet(d, DIM_SHORT[d], [(r, f'{rating(r, "sm")}<span class=bar style="width:{int(70 * cnt.get(r, 0) / total)}px"></span>', cnt.get(r, 0))
                                          for r in "ABCDE"]))
    failing = gates.get("FAILED", 0)
    head = page_head([("Projects", None)], "Projects",
                     meta=[f'{len(projects)} project{"s" if len(projects) != 1 else ""}',
                           f'<span class="chip fail">{failing} failing on main</span>' if failing else "all passing",
                           f'{len(allrows)} analyses'])
    body = (head + '<div class=page data-filter-root><div class=withfacets>'
            f'<aside class=facets>{"".join(fac)}</aside><div>'
            f'<div class=toolbar><input class=input data-search placeholder="Filter by name" value="{e(query)}" style="width:260px">'
            f'<div class=r><span class=count><b data-shown>{len(cards)}</b> projects</span><select class=input data-sort aria-label="Sort">'
            f'<option value=name>Sort by name</option><option value=last>Last analysis</option><option value=issues>Most issues</option></select></div></div>'
            + (f'<div class=pcards data-filter-list>{"".join(cards)}</div>' if cards else
               '<div class="panel empty">No projects to show. Private projects open from the link in their pull request. '
               '<a href="/setup">Connect a repository</a>: one CI step, and the first analysis creates the project.</div>')
            + '</div></div></div>')
    return shell("Projects", body, active="projects", q=query)


def account_page(store, owner: str, viewer) -> str | None:
    """An account (GitHub user or organisation): created by its first analysis, lists what this viewer may see."""
    with store.db() as c:
        exists = c.execute("select 1 from projects where owner=? limit 1", (owner,)).fetchone()
    if not exists:
        return None
    name = owner.split("/", 1)[1]
    projects, allrows = visible(store, viewer, owner)
    if not projects:                       # an account with only private projects looks like no account
        return None
    cards, gates, _ = project_cards(store, projects, allrows)
    failing = gates.get("FAILED", 0)
    extra = f'<img class=ghav src="https://github.com/{e(name)}.png?size=64" alt="" width=32 height=32>'
    head = page_head([(name, None)], name, extra=extra,
                     right=f'<a class=btn href="https://github.com/{e(name)}" target=_blank rel=noopener>{icon("external")}GitHub</a>',
                     meta=[f'{len(projects)} project{"s" if len(projects) != 1 else ""} you can see',
                           f'<span class="chip fail">{failing} failing</span>' if failing else
                           ("all passing" if gates.get("PASSED") == len(projects) else "")])
    body = head + '<div class=page>' + (
        f'<div class=pcards>{"".join(cards)}</div>' if cards else
        '<div class="panel empty">The projects of this account are private. Open them from the link Assay posted in a pull request.</div>') + '</div>'
    return shell(name, body, active="projects")


# ---- summary -------------------------------------------------------------------------------------------------------------------

def _conds(g: dict) -> str:
    out = []
    for c in sorted(g.get("conditions", []), key=lambda c: c["ok"]):
        cls = "ok" if c["ok"] else ("soft" if c.get("soft") else "bad")
        ic = icon("check" if c["ok"] else ("alert" if c.get("soft") else "x"))
        name = c["name"].lower()
        if str(c["actual"]) == "1":
            name = name.replace("journeys", "journey").replace("issues", "issue")
        out.append(f'<li class={cls}><span class=ic>{ic}</span><div><b>{e(c["actual"])} {e(name)}</b>'
                   f'<span>{"Required" if not c["ok"] else "Met:"} {e(c["op"])} {e(c["threshold"])}</span></div></li>')
    return f'<ul class=conds>{"".join(out)}</ul>'


def summary_page(ctx: Ctx) -> str:
    if not ctx.a:
        return no_analysis(ctx, "Summary", "")
    a, r = ctx.a, ctx.row
    s, g = a["summary"], a["gate"]
    failed = [c for c in g["conditions"] if not c["ok"] and not c.get("soft")]
    st = g["status"]
    warned = [c for c in g["conditions"] if not c["ok"] and c.get("soft") and g.get("first_analysis")]
    why = (f'{len(failed)} condition{"s" if len(failed) != 1 else ""} failed' if failed else
           ("Too many journeys could not be checked" if st == "INCONCLUSIVE" else
            "First analysis: nothing to compare with yet, so problems are warnings" if warned else "All conditions met"))
    ref = ctx.ref
    ref_txt = (f'Compared with <a href="{e(f"{purl(ctx.key)}?analysis={ref["id"]}")}">{e(ref["branch"])} @ <span class=mono>{e((ref["sha"] or "")[:7])}</span></a>'
               f' · analysis #{ref["id"]}, {ago(ref["created"])}' if ref else "")
    hero = (f'<div class="qg {st}"><div class=big>{icon({"PASSED": "check", "FAILED": "x"}.get(st, "alert"))}</div><div>'
            f'<div class=lbl>Quality gate {icon("gate")}</div><div class=st>{e({"PASSED": "Passed", "FAILED": "Failed"}.get(st, "Inconclusive"))}</div>'
            f'<div class=reason>{why}</div></div>'
            f'<div style="margin-left:auto;text-align:right" class=mute>{ref_txt}</div></div>')

    pr_mode = bool(ctx.pr)
    has_new = _new_code(ctx)
    ch = a.get("changes") or {}
    titles = {c["case_id"]: c["title"] or c["case_id"] for c in a["cases"]}
    new_issues = [i for i in a["issues"] if i.get("new")] if has_new else []
    sev_new = Counter(i["severity"] for i in new_issues)
    nf_chip = f'<span class="chip {"fail" if failed else "pass"}">{len(failed)} failed</span>'

    def jlist(ids):
        return "".join(f'<div style="margin-top:6px;font-size:13px"><a href="{e(ctx.url("journeys/" + i))}">{e(titles.get(i, i))}</a></div>' for i in ids[:4])

    # new code pane
    if has_new:
        sevs = " ".join(f'<span class="sev {k}">{icon(k)}{sev_new[k]} {k}</span>' for k in SEV_ORDER if sev_new.get(k))
        rn = a.get("ratings_new") or {}
        dimrow = "".join(f'<div class=measure><div class=t>{e(DIM_SHORT[d])}</div><div class=row><span class=v style="font-size:22px">'
                         f'{a["dimensions"].get(d, {}).get("new", 0)}<small>new</small></span>{rating(rn.get(d))}</div></div>' for d in DIM_SHORT)
        right = (f'<div class=measures>'
                 f'<div class=measure><div class=t>{icon("journey")} Newly failing journeys</div><div class=row><a class="v {"bad" if ch.get("regressions") else ""}" href="{e(ctx.url("journeys"))}">{len(ch.get("regressions", []))}</a></div>'
                 f'<div class=s>{jlist(ch.get("regressions", [])) or "No journey started failing."}</div></div>'
                 f'<div class=measure><div class=t>{icon("check")} Fixed journeys</div><div class=row><a class="v {"good" if ch.get("fixed") else ""}" href="{e(ctx.url("journeys"))}">{len(ch.get("fixed", []))}</a></div>'
                 f'<div class=s>{jlist(ch.get("fixed", [])) or "Nothing that failed before passes now."}</div></div>'
                 f'<div class=measure><div class=t>{icon("issues")} New issues</div><div class=row><a class=v href="{e(ctx.url("issues", mode="new"))}">{len(new_issues)}</a></div>'
                 f'<div class=s>{sevs or "No new issues."}</div></div>'
                 f'</div><div class="measures c4" style="border-top:0">{dimrow}<div class=measure><div class=t>Inconclusive</div><div class=row>'
                 f'<span class=v style="font-size:22px">{s["INCONCLUSIVE"]}</span></div><div class=s>environment, not product</div></div></div>')
        left = (_conds(g) if pr_mode else
                f'<div class=mute style="font-size:13px">New code on a branch is what changed since its previous analysis. '
                f'The gate of a branch counts every failing journey; open the Overall tab.</div>')
        new_pane = f'<div class=split><div><h3 style="margin-bottom:6px">{"Conditions" if pr_mode else "New code"}</h3>{left}</div><div>{right}</div></div>'
    else:
        new_pane = ('<div class=empty>First analysis of this branch: there is nothing to compare with, so every finding counts. '
                    'The Overall tab shows them.</div>')

    # overall pane
    cov = a.get("coverage") or {}
    bs = s.get("by_severity", {})
    sevs_all = " ".join(f'<span class="sev {k}">{icon(k)}{bs[k]} {k}</span>' for k in SEV_ORDER if bs.get(k))
    pass_frac = s["PASS"] / s["cases"] if s["cases"] else None
    top = (f'<div class=measures>'
           f'<div class=measure><div class=t>{icon("journey")} Journeys</div><div class=row><a class=v href="{e(ctx.url("journeys"))}">{s["PASS"]}<small>/ {s["cases"]} passing</small></a>{donut(pass_frac, 40)}</div>'
           f'<div class=s>{s["FAIL"]} failing · {s["INCONCLUSIVE"]} inconclusive</div></div>'
           f'<div class=measure><div class=t>{icon("screens")} Screens</div><div class=row><a class=v href="{e(ctx.url("screens"))}">{"—" if cov.get("ratio") is None else f"{cov["ratio"]:.0%}"}<small>covered</small></a>{donut(cov.get("ratio"), 40)}</div>'
           f'<div class=s>{s["pages_scanned"]} screens scanned on {s["routes_scanned"]} routes; {len(cov.get("covered", []))} of {len(cov.get("discovered", []))} routes reached by journeys</div></div>'
           f'<div class=measure><div class=t>{icon("issues")} Issues</div><div class=row><a class=v href="{e(ctx.url("issues", mode="all"))}">{s["issues"]}</a></div>'
           f'<div class=s>{sevs_all or "No issues."}</div></div></div>')
    ra = a["ratings"]
    dims = "".join(f'<div class=measure><div class=t>{e(DIM_SHORT[d])}</div><div class=row><a class=v style="font-size:24px" href="{e(ctx.url("issues", mode="all", dim=d))}">'
                   f'{a["dimensions"].get(d, {}).get("issues", 0)}<small>issues</small></a>{rating(ra.get(d), "lg")}</div>'
                   f'<div class=s>{e(DIM_HELP[d])}</div></div>' for d in DIM_SHORT)
    judge = a.get("judge") or {}
    dims += (f'<div class=measure><div class=t>AI judge</div><div class=row><span class=v style="font-size:24px">{judge.get("calls", 0)}<small>calls</small></span></div>'
             f'<div class=s>{e(judge.get("backend") or "off")} {e(judge.get("model") or "")} · ${judge.get("cost_usd", 0):.2f}</div></div>')
    overall_left = _conds(g) if not pr_mode else ('<div class=mute style="font-size:13px">A pull request is gated on new code only. '
                                                  'This tab shows the whole app at this commit, old problems included.</div>')
    overall_pane = (f'<div class=split><div><h3 style="margin-bottom:6px">{"Conditions" if not pr_mode else "Overall"}</h3>{overall_left}</div>'
                    f'<div>{top}<div class="measures c4" style="border-top:0">{dims}</div></div></div>')

    default = "new" if (pr_mode and has_new) else "overall"
    tabs = (f'<div class=tabs data-tabs=sum role=tablist>'
            f'<button data-tab=new class="{"on" if default == "new" else ""}">New code {nf_chip if pr_mode and has_new else (f"<span class=\"chip brand\">{len(new_issues)} new</span>" if has_new else "")}</button>'
            f'<button data-tab=overall class="{"on" if default == "overall" else ""}">Overall {nf_chip if not pr_mode else ""}</button></div>'
            f'<div class=tabpane data-pane="sum:new" {"hidden" if default != "new" else ""}>{new_pane}</div>'
            f'<div class=tabpane data-pane="sum:overall" {"hidden" if default != "overall" else ""}>{overall_pane}</div>')

    # failing journeys
    bad = [c for c in a["cases"] if c["verdict"] != "PASS"]
    rows = "".join(
        f'<tr><td>{verdict(c["verdict"])}</td><td><a class=title href="{e(ctx.url("journeys/" + c["case_id"]))}">{e(c["title"] or c["case_id"])}</a>'
        f'<div class=sub><span class=mono>{e(c["case_id"])}</span>{" · <span class=\"chip fail\" style=\"height:18px\">new failure</span>" if c["case_id"] in ch.get("regressions", []) else ""}</div>'
        f'<div class=sub style="max-width:640px;color:var(--text)">{e(_first(c["summary"], 180))}</div></td>'
        f'<td>{e(c["owner"] or "—")}</td><td>{e(c["severity"])}</td>'
        f'<td>{_thumb(ctx, c.get("screenshot"))}</td></tr>' for c in bad)
    bad_panel = (f'<div class=panel style="margin-top:20px"><div class=panel-h><h2>Journeys that need attention</h2><span class="chip fail">{len(bad)}</span>'
                 f'<a class=r href="{e(ctx.url("journeys"))}">All journeys →</a></div><div class=scroll><table class=tbl><thead><tr><th>Result</th><th>Journey and reason</th>'
                 f'<th>Owner</th><th>Severity</th><th>End screen</th></tr></thead><tbody>{rows}</tbody></table></div></div>') if bad else ""

    # activity mini
    hist = ctx.history()[-12:]
    chart = line_chart([("Journeys passing", [h["pass"] / h["cases"] if h["cases"] else None for h in hist], "#2457c5")],
                       [_fmt(h["created"], "%-d %b %H:%M") for h in hist], width=1100, height=200, ymax=1, pct=True,
                       links=[f"{purl(ctx.key)}?analysis={h['id']}" for h in hist],
                       dot_colors=[{"PASSED": "#11734a", "FAILED": "#bf3128"}.get(h["status"], "#9a5806") for h in hist])
    act = (f'<div class=panel style="margin-top:20px"><div class=panel-h><h2>Activity</h2><span class=mute>{"pull request" if ctx.pr else e(ctx.branch)} · '
           f'{len(ctx.history())} analyses</span><a class=r href="{e(ctx.url("activity"))}">Full activity →</a></div>'
           f'<div class=panel-b>{chart}<div class=mute style="font-size:12px;margin-top:4px">Share of journeys passing per analysis; dot colour is the gate.</div></div></div>')

    body = (project_head(ctx, "Summary", "") + f'<div class=page>{hero}<div class=panel>{tabs}</div>{bad_panel}{act}</div>')
    return shell(f"{ctx.p['title']}", body, active="projects", snav=snav(ctx, "summary"))


def _first(msg: str, n: int = 220) -> str:
    m = (msg or "").split(" | ")[0]
    return m if len(m) <= n else m[: n - 1] + "…"


def _thumb(ctx: Ctx, rel: str | None, cls: str = "thumb") -> str:
    if not rel:
        return ""
    src = f"/a/{ctx.row['id']}/{rel}"
    return f'<img class={cls} loading=lazy src="{e(src)}" data-zoom="{e(src)}" alt="">'


# ---- issues ----------------------------------------------------------------------------------------------------------------------

def issues_page(ctx: Ctx) -> str:
    if not ctx.a:
        return no_analysis(ctx, "Issues", "issues")
    a = ctx.a
    has_new = _new_code(ctx)
    mode = ctx.q.get("mode") or ("new" if (ctx.pr and has_new) else "all")
    if mode == "new" and not has_new:
        mode = "all"
    issues = [i for i in a["issues"] if i.get("new")] if mode == "new" else list(a["issues"])
    n_new = sum(1 for i in a["issues"] if i.get("new")) if has_new else 0
    titles = {c["case_id"]: c["title"] or c["case_id"] for c in a["cases"]}
    pre_dim = ctx.q.get("dim") or ""

    def loc(i):
        return "journey" if (i["where"] or "").startswith("case:") else "screen"
    groups: "OrderedDict[str, list]" = OrderedDict()
    sev_rank = {s: k for k, s in enumerate(SEV_ORDER)}
    for i in sorted(issues, key=lambda i: (loc(i) != "journey", i["where"] or "", sev_rank.get(i["severity"], 9))):
        groups.setdefault(i["where"] or "—", []).append(i)

    cards = []
    for where, items in groups.items():
        if where.startswith("case:"):
            cid = where[5:]
            head = f'{icon("journey")}<span class=k>Journey</span><a href="{e(ctx.url("journeys/" + cid))}">{e(titles.get(cid, cid))}</a>'
        else:
            head = f'{icon("screens")}<span class=k>Screen</span><span class=mono>{e(where)}</span>'
        body = []
        for i in items:
            msgs = [m for m in (i["message"] or "").split(" | ") if m]
            srcs = [s for s in (i.get("sources") or [])]
            src_html = "".join(f'<li><a href="{e(ctx.url("journeys/" + s))}">{e(titles[s])}</a></li>' if s in titles else f'<li class=mono>{e(s)}</li>'
                               for s in srcs[:12])
            ev = i.get("evidence")
            img = (f'<img loading=lazy data-src="/a/{ctx.row["id"]}/{e(ev)}" data-zoom="/a/{ctx.row["id"]}/{e(ev)}" alt="Screen where the issue was seen">'
                   if ev and ev.endswith((".png", ".jpg")) else '<div class=mute>No screenshot for this issue.</div>')
            body.append(
                f'<div class=issue data-item data-dim="{e(i["dimension"])}" data-sev="{e(i["severity"])}" data-rule="{e(i["rule"])}" data-loc="{loc(i)}" '
                f'data-text="{e((i["title"] + " " + (i["message"] or "") + " " + (i["where"] or "")).lower())}">'
                f'<div class=issue-m><div class=issue-t><span class=msg>{e(i["title"])}</span><span class=tags>'
                f'{"<span class=\"chip new\">New</span>" if i.get("new") and has_new else ""}<span class="chip out mono">{e(i["rule"])}</span></span></div>'
                f'<div class=detail>{e(_first(i["message"], 260))}</div>'
                f'<div class=issue-c>{dim_sev(i["dimension"], i["severity"])}</div></div>'
                f'<div class=issue-f><span>Seen {i["count"]}×</span><span>{len(srcs)} source{"s" if len(srcs) != 1 else ""}</span>'
                f'<span class=r><span class=mono>{e(i["fingerprint"])}</span></span></div>'
                f'<div class=issue-x hidden><div><h4 style="font-size:13px">Every occurrence</h4><ul>{"".join(f"<li>{e(m)}</li>" for m in msgs[:20])}</ul>'
                f'{f"<h4 style=\"font-size:13px;margin-top:12px\">Seen during</h4><ul>{src_html}</ul>" if src_html else ""}</div><div>{img}</div></div></div>')
        cards.append(f'<section class=ig data-group><div class=ig-h>{head}</div>{"".join(body)}</section>')

    def facet(name, label, values, pre=""):
        btns = "".join(f'<button type=button class="{"on" if v == pre else ""}" data-facet="{name}" data-value="{e(v)}">{lab}<span class=n>{n}</span></button>'
                       for v, lab, n in values if n)
        return f'<div class=facet><h4>{e(label)}</h4>{btns or "<span class=mute style=font-size:12.5px>none</span>"}</div>'
    cd, cs, cr, cl = Counter(i["dimension"] for i in issues), Counter(i["severity"] for i in issues), Counter(i["rule"] for i in issues), Counter(loc(i) for i in issues)
    fac = (facet("dim", "Quality", [(d, e(DIM_SHORT[d]), cd.get(d, 0)) for d in DIM_SHORT], pre_dim)
           + facet("sev", "Severity", [(s_, sev(s_), cs.get(s_, 0)) for s_ in SEV_ORDER])
           + facet("loc", "Where", [("journey", f'{icon("journey")} Journeys', cl.get("journey", 0)), ("screen", f'{icon("screens")} Screens', cl.get("screen", 0))])
           + facet("rule", "Rule", [(k, f'<span class=mono style="font-size:12px">{e(k)}</span>', n) for k, n in cr.most_common(14)]))
    seg = (f'<div class=seg>' + (f'<a class="{"on" if mode == "new" else ""}" href="{e(ctx.url("issues", mode="new"))}">New code <span class=n>{n_new}</span></a>' if has_new else "")
           + f'<a class="{"on" if mode == "all" else ""}" href="{e(ctx.url("issues", mode="all"))}">Overall <span class=n>{len(a["issues"])}</span></a></div>')
    pre_js = ""
    body = (project_head(ctx, "Issues", "issues") + f'<div class=page data-filter-root data-predim="{e(pre_dim or "")}"><div class=withfacets>'
            f'<aside class=facets>{fac}</aside><div><div class=toolbar>{seg}<input class=input data-search placeholder="Search issues" style="width:240px">'
            f'<div class=r><span class=count><b data-shown>{len(issues)}</b> issues</span></div></div>'
            + (f'<div data-filter-list>{"".join(cards)}</div>' if cards else '<div class="panel empty">No issues here.</div>')
            + f'</div></div></div>{pre_js}')
    return shell(f"Issues · {ctx.p['title']}", body, active="projects", snav=snav(ctx, "issues"))


# ---- journeys ------------------------------------------------------------------------------------------------------------------

def _history_map(ctx: Ctx, limit: int = 12) -> tuple[list, dict]:
    hist = ctx.history()
    if ctx.row:
        hist = [h for h in hist if h["created"] <= ctx.row["created"]]
    hist = hist[-limit:]
    per: dict[str, list] = {}
    for h in hist:
        ha = analysis(ctx.store, h["id"]) or {}
        for c in ha.get("cases", []):
            per.setdefault(c["case_id"], []).append((h, c["verdict"]))
    return hist, per


def journeys_page(ctx: Ctx) -> str:
    if not ctx.a:
        return no_analysis(ctx, "Journeys", "journeys")
    a = ctx.a
    ch = a.get("changes") or {}
    hist, per = _history_map(ctx)
    cnt = Counter(c["verdict"] for c in a["cases"])
    rows = []
    for c in sorted(a["cases"], key=lambda c: ({"FAIL": 0, "INCONCLUSIVE": 1, "PASS": 2}.get(c["verdict"], 3), c["case_id"])):
        dots = "".join(f'<a href="{e(purl(ctx.key))}/journeys/{e(c["case_id"])}?analysis={h["id"]}" title="#{h["id"]} {e(when(h["created"]))}: {v}"><i class="{v}"></i></a>'
                       for h, v in per.get(c["case_id"], []))
        tag = ('<span class="chip fail" style="height:18px">new failure</span>' if c["case_id"] in ch.get("regressions", []) else
               '<span class="chip pass" style="height:18px">fixed</span>' if c["case_id"] in ch.get("fixed", []) else "")
        dev = f'{icon("phone" if (c.get("viewport") or "").startswith(("mobile", "phone", "ipad", "tablet")) else "screens")} {e(c.get("viewport") or "")}'
        rows.append(f'<tr data-item data-verdict="{c["verdict"]}" data-text="{e((c["title"] + " " + c["case_id"]).lower())}">'
                    f'<td>{verdict(c["verdict"])}</td><td><a class=title href="{e(ctx.url("journeys/" + c["case_id"]))}">{e(c["title"] or c["case_id"])}</a>'
                    f'<div class=sub><span class=mono>{e(c["case_id"])}</span> {tag} {" ".join(f"<span class=chip style=height:18px>{e(t)}</span>" for t in (c.get("tags") or [])[:3])}</div></td>'
                    f'<td>{e(c["severity"])}</td><td class=mute style="white-space:nowrap">{dev}<div class=sub>{e(c.get("browser") or "")}</div></td>'
                    f'<td><span class=dots>{dots}</span></td><td class="r mute" style="white-space:nowrap">{c["duration_s"]:.1f} s</td><td>{_thumb(ctx, c.get("screenshot"))}</td></tr>')
    seg = ('<div class=seg>' + "".join(f'<button type=button data-facet=verdict data-value="{v}">{lab} <span class=n>{cnt.get(v, 0)}</span></button>'
                                       for v, lab in (("FAIL", "Failed"), ("INCONCLUSIVE", "Inconclusive"), ("PASS", "Passed"))) + '</div>')
    body = (project_head(ctx, "Journeys", "journeys") + '<div class=page data-filter-root>'
            f'<div class=toolbar>{seg}<input class=input data-search placeholder="Search journeys" style="width:240px">'
            f'<div class=r><span class=count><b data-shown>{len(rows)}</b> journeys</span></div></div>'
            f'<div class=panel><div class=scroll><table class=tbl><thead><tr><th>Result</th><th>Journey</th><th>Severity</th><th>Device</th>'
            f'<th>Last {len(hist)} analyses</th><th class=r>Time</th><th>End screen</th></tr></thead><tbody data-filter-list>{"".join(rows)}</tbody></table></div></div></div>')
    return shell(f"Journeys · {ctx.p['title']}", body, active="projects", snav=snav(ctx, "journeys"))


def _key_of(rec: dict):
    for k in ("id", "uuid", "key", "slug", "name"):
        if isinstance(rec, dict) and k in rec:
            return f"{k}={rec[k]}"
    return None


def _short(v, n=140) -> str:
    s = json.dumps(v, ensure_ascii=False, default=str)
    return s if len(s) <= n else s[: n - 1] + "…"


def data_changes(before: dict, after: dict) -> str:
    out = []
    for name in sorted(set(before or {}) | set(after or {})):
        b, a = (before or {}).get(name), (after or {}).get(name)
        if b == a:
            continue
        lines = []
        if isinstance(b, list) and isinstance(a, list) and all(isinstance(x, dict) for x in b + a) and all(_key_of(x) for x in b + a):
            mb, ma = {_key_of(x): x for x in b}, {_key_of(x): x for x in a}
            for k in ma.keys() - mb.keys():
                lines.append(f'<div class=add>+ {e(k)} {e(_short({kk: vv for kk, vv in ma[k].items() if kk not in ("id",)}, 220))}</div>')
            for k in mb.keys() - ma.keys():
                lines.append(f'<div class=del>− {e(k)}</div>')
            for k in mb.keys() & ma.keys():
                if mb[k] != ma[k]:
                    fields = [f for f in set(mb[k]) | set(ma[k]) if mb[k].get(f) != ma[k].get(f)]
                    lines.append(f'<div class=chg>~ {e(k)}: ' + "; ".join(f'{e(f)} {e(_short(mb[k].get(f), 60))} → {e(_short(ma[k].get(f), 60))}' for f in sorted(fields)[:6]) + '</div>')
        else:
            lines.append(f'<div class=chg>{e(_short(b, 160))} → {e(_short(a, 160))}</div>')
        out.append(f'<div class=p>{e(name)}</div>{"".join(lines[:12])}')
    return f'<div class=diff>{"".join(out)}</div>' if out else '<div class=mute>No data changed in the probes.</div>'


def journey_page(ctx: Ctx, case_id: str) -> str | None:
    if not ctx.a:
        return no_analysis(ctx, "Journey", "journeys")
    c = next((c for c in ctx.a["cases"] if c["case_id"] == case_id), None)
    if not c:
        return None
    aid = ctx.row["id"]
    ev = evidence(ctx.store, aid, case_id)
    base = f"/a/{aid}/cases/{case_id}/"
    v = c["verdict"]
    hist, per = _history_map(ctx, 20)
    dots = "".join(f'<a href="{e(purl(ctx.key))}/journeys/{e(case_id)}?analysis={h["id"]}" title="#{h["id"]}: {vv}"><i class="{vv}"></i></a>'
                   for h, vv in per.get(case_id, []))
    hero = (f'<div class="qg {"PASSED" if v == "PASS" else ("FAILED" if v == "FAIL" else "INCONCLUSIVE")}"><div class=big>'
            f'{icon({"PASS": "check", "FAIL": "x"}.get(v, "alert"))}</div><div><div class=lbl>Journey</div>'
            f'<div class=st>{ {"PASS": "Passed", "FAIL": "Failed"}.get(v, "Inconclusive") }</div>'
            f'<div class=reason>{e("Owner: " + c["owner"]) if c.get("owner") else "All checks met"}</div></div>'
            f'<div style="margin-left:auto;text-align:right"><div class=mute style="font-size:12px;margin-bottom:4px">History on this {"pull request" if ctx.pr else "branch"}</div>'
            f'<span class=dots>{dots}</span></div></div>')
    why = (f'<div class="why {v}" style="margin-bottom:20px"><b>Why it {"failed" if v == "FAIL" else "could not be checked"}</b><div style="margin-top:4px">{e(c["summary"])}</div></div>'
           if v != "PASS" else "")
    steps = []
    for st in c.get("steps", []):
        shot = st.get("screenshot")
        img = f'<img loading=lazy src="{e(base + shot)}" data-zoom="{e(base + shot)}" alt="screen after this step">' if shot else ""
        err_html = f'<div class=err>{e(st["error"])}</div>' if st.get("error") else ""
        steps.append(f'<li class="{"" if st.get("ok") else "bad"}"><span class=n>{int(st.get("i", 0)) + 1}</span><div><span class=act>{e(st.get("action"))}</span>'
                     f' <span class=mute style="font-size:12px">{(str(st["ms"]) + " ms") if st.get("ms") is not None else "timed out"}</span><div class=sum>{e(st.get("summary"))}</div>'
                     f'{err_html}</div>{img}</li>')
    checks = []
    for it in c["items"]:
        stt = it["status"]
        cls = {"pass": "ok", "fail": "bad"}.get(stt, "soft")
        ic = icon({"pass": "check", "fail": "x"}.get(stt, "alert"))
        spec = it["spec"] if isinstance(it["spec"], str) else _short(it["spec"], 120)
        detail = f'<span>{e(it["detail"])}</span>' if it.get("detail") and stt != "pass" else ""
        checks.append(f'<li class={cls}><span class=ic>{ic}</span><div><b>{e(it["level"])} · {e(it["kind"])}{" · AI judge" if it["by"] == "judge" else ""}</b>'
                      f'<span style="display:block;color:var(--text)">{e(spec)}</span>{detail}</div></li>')
    sensors = ev.get("sensors") or {}
    sens_rows = []
    for k, label in (("page_errors", "Uncaught exceptions"), ("console", "Console errors"), ("failed_requests", "Failed requests"),
                     ("bad_responses", "HTTP errors"), ("slow_responses", "Slow responses")):
        vals = sensors.get(k) or []
        if k == "console":
            vals = [x for x in vals if (x.get("type") if isinstance(x, dict) else "") in ("error", "assert")] or vals[:0]
        sens_rows.append(f'<dt>{label}</dt><dd>{len(vals)}' + "".join(f'<div class="mono mute" style="font-size:11.5px">{e(_short(x, 140))}</div>' for x in vals[:3]) + '</dd>')
    kv = "".join(f'<dt>{k}</dt><dd>{v_}</dd>' for k, v_ in (
        ("Journey", f'<span class=mono>{e(case_id)}</span>'), ("Severity", e(c["severity"])), ("Quality", e(DIM_SHORT.get(c["dimension"], c["dimension"]))),
        ("Device", f'{e(c.get("viewport"))} · {e(c.get("browser"))}'), ("Signed in as", e(c.get("account") or "visitor")),
        ("Duration", f'{c["duration_s"]:.1f} s'), ("Ended on", f'<span class=mono>{e(c.get("final_url") or "—")}</span>'),
        ("Owner", e(c.get("owner") or "—")), ("Analysis", f'#{aid} · {e(when(ctx.row["created"]))}')))
    final = c.get("screenshot")
    body = (project_head(ctx, c["title"] or case_id, f"journeys/{case_id}").replace(
        f'<span class=ink>{e(c["title"] or case_id)}</span>', f'<a href="{e(ctx.url("journeys"))}">Journeys</a><span class=sep>/</span><span class=ink>{e(case_id)}</span>', 1)
        + f'<div class=page>{hero}{why}<div class=grid style="grid-template-columns:minmax(0,1.6fr) minmax(0,1fr)">'
        f'<div><div class=panel><div class=panel-h><h2>{icon("journey")} Steps</h2><span class=mute>{len(steps)} steps, screenshot after each</span></div>'
        f'<div class=panel-b style="padding-top:4px;padding-bottom:4px"><ol class=steps>{"".join(steps) or "<li class=mute>No steps recorded.</li>"}</ol></div></div>'
        f'<div class=panel><div class=panel-h><h2>{icon("data")} Data changes</h2><span class=mute>app state read before and after the journey</span></div>'
        f'<div class=panel-b>{data_changes(ev.get("state_before"), ev.get("state_after"))}</div></div></div>'
        f'<div><div class=panel><div class=panel-h><h2>Checks</h2><span class=mute>{sum(1 for i in c["items"] if i["status"] == "pass")}/{len(c["items"])} met</span></div>'
        f'<div class=panel-b style="padding-top:0;padding-bottom:0"><ul class=conds>{"".join(checks)}</ul></div></div>'
        f'<div class=panel><div class=panel-h><h2>Final screen</h2></div><div class=panel-b>{_thumb(ctx, final, "shotbig")}</div></div>'
        f'<div class=panel><div class=panel-h><h2>{icon("terminal")} Sensors</h2></div><div class=panel-b><dl class=kv>{"".join(sens_rows)}</dl></div></div>'
        f'<div class=panel><div class=panel-h><h2>Details</h2></div><div class=panel-b><dl class=kv>{kv}</dl></div></div></div></div></div>')
    return shell(f"{c['title']} · {ctx.p['title']}", body, active="projects", snav=snav(ctx, "journeys"))


# ---- screens ---------------------------------------------------------------------------------------------------------------------

def screens_page(ctx: Ctx) -> str:
    if not ctx.a:
        return no_analysis(ctx, "Screens", "screens")
    a = ctx.a
    by_route = Counter(i["where"] for i in a["issues"])
    vps = Counter(p["viewport"] for p in a["pages"])
    cards = []
    for p in a["pages"]:
        if not p.get("screenshot"):
            continue
        src = f"/a/{ctx.row['id']}/{p['screenshot']}"
        vit = p.get("vitals") or {}
        lcp = f'<span class="chip {"warn" if vit.get("lcp", 0) > 2500 else ""}">LCP {round(vit["lcp"])} ms</span>' if vit.get("lcp") else ""
        cards.append(f'<div class=card data-item data-vp="{e(p["viewport"])}" data-text="{e(p["route"])}"><img loading=lazy src="{e(src)}" data-zoom="{e(src)}" alt="">'
                     f'<div class=cb><span class=route>{e(p["route"])}</span><div class=meta><span class=chip>{icon("phone" if p["viewport"] != "desktop" else "screens")} {e(p["viewport"])}</span>'
                     f'<span class="chip {"warn" if p.get("a11y") else "pass"}">{p.get("a11y", 0)} a11y</span>{lcp}'
                     f'<span class="chip {"fail" if by_route.get(p["route"]) else ""}">{by_route.get(p["route"], 0)} issues</span></div></div></div>')
    cov = a.get("coverage") or {}
    unc = cov.get("uncovered") or []
    seg = '<div class=seg>' + "".join(f'<button type=button data-facet=vp data-value="{e(v)}">{e(v)} <span class=n>{n}</span></button>' for v, n in vps.items()) + '</div>'
    note = (f'<div class=panel style="margin-bottom:16px"><div class=panel-b style="display:flex;gap:14px;align-items:center">{donut(cov.get("ratio"), 40)}<div>'
            f'<b class=ink>{"—" if cov.get("ratio") is None else f"{cov["ratio"]:.0%}"} of discovered routes are reached by journeys.</b>'
            f'<div class=mute style="font-size:13px">Not covered by any journey: <span class=mono>{e(", ".join(unc) or "none")}</span></div></div></div></div>') if cov else ""
    body = (project_head(ctx, "Screens", "screens") + f'<div class=page data-filter-root>{note}<div class=toolbar>{seg}'
            f'<input class=input data-search placeholder="Filter by route" style="width:220px"><div class=r><span class=count><b data-shown>{len(cards)}</b> screens</span></div></div>'
            f'<div class=gallery data-filter-list>{"".join(cards)}</div></div>')
    return shell(f"Screens · {ctx.p['title']}", body, active="projects", snav=snav(ctx, "screens"))


# ---- activity --------------------------------------------------------------------------------------------------------------------

def activity_page(ctx: Ctx) -> str:
    hist = ctx.history()
    if not hist:
        return no_analysis(ctx, "Activity", "activity")
    labels = [_fmt(h["created"], "%-d %b %H:%M") for h in hist]
    links = [f"{purl(ctx.key)}?analysis={h['id']}" for h in hist]
    dc = [{"PASSED": "#11734a", "FAILED": "#bf3128"}.get(h["status"], "#9a5806") for h in hist]
    charts = {
        "pass": line_chart([("Journeys passing", [h["pass"] / h["cases"] if h["cases"] else None for h in hist], "#2457c5")], labels, ymax=1, pct=True, links=links, dot_colors=dc),
        "issues": line_chart([("Issues", [h["issues"] for h in hist], "#c2410c")], labels, links=links),
        "fail": line_chart([("Failing journeys", [h["fail"] for h in hist], "#bf3128")], labels, links=links),
    }
    events, prev = [], None
    for h in hist:
        change = ""
        if prev and prev["status"] != h["status"]:
            change = f' <span class="chg" style="color:{"var(--fail)" if h["status"] == "FAILED" else "var(--pass)"}">{e(h["status"].capitalize())} (was {e(prev["status"].lower())})</span>'
        events.append((h, change))
        prev = h
    days: "OrderedDict[str, list]" = OrderedDict()
    for h, ch in reversed(events):
        days.setdefault(_fmt(h["created"], "%A, %-d %B %Y", "Unknown date"), []).append((h, ch))
    tl = []
    for d, evs in days.items():
        tl.append(f'<li class=day>{e(d)}</li>')
        for h, ch in evs:
            newtxt = f' · {h["new_issues"]} new' if h["new_issues"] else ""
            tl.append(f'<li class=ev><span class=tm>{_fmt(h["created"], "%H:%M")}</span><div class=what>'
                      f'<a href="{e(purl(ctx.key))}?analysis={h["id"]}"><b>Analysis #{h["id"]}</b></a> · <span class=mono>{e((h["sha"] or "")[:7])}</span><br>'
                      f'{gate(h["status"])}{ch} <span class=mute>· {h["pass"]}/{h["cases"]} journeys · {h["issues"]} issues'
                      f'{newtxt}</span></div></li>')
    tabs = ('<div class=tabs data-tabs=act><button data-tab=pass class=on>Journeys passing</button><button data-tab=fail>Failing journeys</button>'
            '<button data-tab=issues>Issues</button></div>'
            + "".join(f'<div class=tabpane data-pane="act:{k}" {"" if k == "pass" else "hidden"} style="padding:18px">{v}</div>' for k, v in charts.items()))
    body = (project_head(ctx, "Activity", "activity") + '<div class=page><div class=grid style="grid-template-columns:340px minmax(0,1fr);align-items:start">'
            f'<div class=panel><div class=panel-h><h2>Events</h2><span class=mute>{len(hist)} analyses</span></div><ul class=timeline>{"".join(tl)}</ul></div>'
            f'<div class=panel>{tabs}<div class=mute style="font-size:12px;padding:0 18px 16px">Each point is an analysis of '
            f'{"this pull request" if ctx.pr else "branch " + e(ctx.branch)}; click it to open that analysis.</div></div></div></div>')
    return shell(f"Activity · {ctx.p['title']}", body, active="projects", snav=snav(ctx, "activity"))


# ---- pull requests, branches -------------------------------------------------------------------------------------------------------

def prs_page(ctx: Ctx) -> str:
    seen, rows = set(), []
    for r in ctx.rows:
        if not r["pr"] or r["pr"] in seen:
            continue
        seen.add(r["pr"])
        rows.append(f'<tr><td class=mono>#{e(r["pr"])}</td><td><a class=title href="{e(purl(ctx.key))}?{e(urlencode({"pr": r["pr"]}))}">{e(r["pr_title"] or r["branch"])}</a>'
                    f'<div class="sub mono">{e(r["branch"])} → {e(r["target"])}</div></td><td>{gate(r["status"])}</td>'
                    f'<td class=r><span class="{"ink" if r["regressed"] else "mute"}" style="font-weight:600;{"color:var(--fail)" if r["regressed"] else ""}">{r["regressed"] or 0}</span></td>'
                    f'<td class=r><span style="font-weight:600;{"color:var(--pass)" if r["fixed"] else ""}">{r["fixed"] or 0}</span></td>'
                    f'<td class=r>{"—" if r["new_issues"] is None else r["new_issues"]}</td><td class=mono>{e((r["sha"] or "")[:7])}</td>'
                    f'<td class=mute title="{e(when(r["created"]))}">{ago(r["created"])}</td></tr>')
    table = (f'<div class=panel><div class=scroll><table class=tbl><thead><tr><th>#</th><th>Pull request</th><th>Quality gate</th><th class=r>Newly failing</th>'
             f'<th class=r>Fixed</th><th class=r>New issues</th><th>Commit</th><th>Analysed</th></tr></thead><tbody>{"".join(rows)}</tbody></table></div></div>'
             if rows else '<div class="panel empty">No pull request has been analysed yet. The Assay step runs on every pull request once it is in CI.</div>')
    body = (page_head([*base_crumbs(ctx.p), ("Pull requests", None)], "Pull requests",
                      meta=[f"{len(rows)} analysed", "each is compared with the latest analysis of its target branch; only what it changes counts for its gate"])
            + f'<div class=page>{table}</div>')
    return shell(f"Pull requests · {ctx.p['title']}", body, active="projects", snav=snav(ctx, "prs"))


def branches_page(ctx: Ctx) -> str:
    seen, rows = set(), []
    for r in ctx.rows:
        if r["pr"] or r["branch"] in seen:
            continue
        seen.add(r["branch"])
        main = r["branch"] == ctx.p["default_branch"]
        rows.append(f'<tr><td>{icon("branch")} <a class=title href="{e(purl(ctx.key))}?{e(urlencode({"branch": r["branch"] or ""}))}">{e(r["branch"])}</a>'
                    f'{" <span class=\"chip brand\">Main branch</span>" if main else ""}</td><td>{gate(r["status"])}</td>'
                    f'<td class=r>{r["pass"]}/{r["cases"]}</td><td class=r>{r["issues"]}</td><td class=mono>{e((r["sha"] or "")[:7])}</td>'
                    f'<td class=mute title="{e(when(r["created"]))}">{ago(r["created"])}</td></tr>')
    body = (page_head([*base_crumbs(ctx.p), ("Branches", None)], "Branches",
                      meta=["a branch is gated on everything: any failing journey blocks a release"])
            + f'<div class=page><div class=panel><div class=scroll><table class=tbl><thead><tr><th>Branch</th><th>Quality gate</th><th class=r>Journeys passing</th>'
            f'<th class=r>Issues</th><th>Commit</th><th>Analysed</th></tr></thead><tbody>{"".join(rows)}</tbody></table></div></div></div>')
    return shell(f"Branches · {ctx.p['title']}", body, active="projects", snav=snav(ctx, "branches"))


# ---- quality gate, setup, rules, docs ------------------------------------------------------------------------------------------------

def _cond_table(g: dict | None) -> str:
    if not g:
        return '<div class=empty>No analysis yet.</div>'
    rows = "".join(f'<tr><td class=ink style="font-weight:500">{e(c["name"])}</td><td class=mono>{e(c["op"])} {e(c["threshold"])}</td>'
                   f'<td class=r>{e(c["actual"])}</td><td>{"<span class=\"chip pass\">met</span>" if c["ok"] else ("<span class=\"chip warn\">warning</span>" if c.get("soft") else "<span class=\"chip fail\">failed</span>")}</td></tr>'
                   for c in g.get("conditions", []))
    return f'<table class=tbl><thead><tr><th>Condition</th><th>Required</th><th class=r>Latest value</th><th>Status</th></tr></thead><tbody>{rows}</tbody></table>'


# ---- benchmarks (the separate workflow for products with AI) ---------------------------------------------------------

BENCH_HELP = ("A benchmark repeats every journey several times per arm: a model answers differently each time, so one run "
              "proves little. <b>Pass rate</b> is the share of journeys that pass on one attempt, with its 95% interval over "
              "journeys. <b>Δ</b> is the paired difference from the baseline arm; ✱ marks a difference beyond chance. "
              "<b>Flaky</b> journeys passed on some attempts and failed on others.")


def _pct(v) -> str:
    return "—" if v is None else f"{v * 100:.0f}%"


def _cibar(r: dict, wide: bool = False) -> str:
    """The pass rate as a dot on a 0–100% track, with its 95% interval as a band."""
    lo, hi = (r.get("ci95") or [None, None])[:2]
    v = r.get("pass@1")
    if v is None:
        return ""
    band = (f'<span class=band style="left:{lo * 100:.1f}%;width:{max(0.0, (hi - lo)) * 100:.1f}%"></span>'
            if lo is not None and hi is not None else "")
    return (f'<span class="cibar{" wide" if wide else ""}" title="{_pct(v)}, 95% interval {_pct(lo)}–{_pct(hi)}">{band}'
            f'<span class=pt style="left:{v * 100:.1f}%"></span></span>')


def _delta(d: dict | None, base: str) -> str:
    if not d:
        return '<span class=faint>baseline</span>'
    m, (lo, hi) = d.get("mean"), (d.get("ci95") or [None, None])[:2]
    if m is None:
        return "—"
    cls = ("good" if m > 0 else "bad") if d.get("significant") else "mute"
    rng = f' <span class=faint>[{lo * 100:+.0f}, {hi * 100:+.0f}]</span>' if lo is not None and hi is not None else ""
    return f'<span class="dl {cls}">{m * 100:+.0f} pp{" ✱" if d.get("significant") else ""}</span>{rng}'


def _bench_scope(r) -> str:
    return (f'{icon("pr")} PR #{e(r["pr"])}' if r["pr"] else f'{icon("branch")} {e(r["branch"] or "—")}') + \
           (f' · <span class=mono>{e((r["sha"] or "")[:7])}</span>' if r["sha"] else "")


def benchmarks_page(ctx: Ctx) -> str:
    head = page_head([*base_crumbs(ctx.p), ("Benchmarks", None)], "Benchmarks",
                     meta=[f'{len(ctx.benches)} benchmark{"s" if len(ctx.benches) != 1 else ""}', "the separate workflow for AI features"])
    if not ctx.benches:
        body = head + ('<div class=page><div class="panel empty">No benchmarks yet. Add the benchmark workflow '
                       '(<span class=mono>command: bench</span>): <a href="/setup">Connect a repository</a>.</div></div>')
        return shell(f"Benchmarks · {ctx.p['title']}", body, active="projects", snav=snav(ctx, "bench"))
    rows = []
    for r in ctx.benches:
        arms = json.loads(r["arms"] or "{}")
        cells = "".join(f'<div class=barm><span class=an>{e(a)}</span><b class=num>{_pct(v.get("pass@1"))}</b>{_cibar(v)}'
                        f'<span class=ad>{_delta({"mean": v.get("diff"), "significant": v.get("significant")} if v.get("diff") is not None else None, r["baseline"])}</span></div>'
                        for a, v in arms.items())
        flaky = sum(v.get("flaky", 0) for v in arms.values())
        rows.append(f'<tr><td class=nw><a class=title href="{e(purl(ctx.key))}/benchmarks/{r["id"]}">Benchmark #{r["id"]}</a>'
                    f'<div class=mute style="font-size:12px">{e(when(r["created"]))}</div></td>'
                    f'<td class=nw>{_bench_scope(r)}<div class=mute style="font-size:12px">{r["cases"]} journeys × {r["attempts"]} attempts</div></td>'
                    f'<td>{cells}</td><td class="r nw">{flaky or "<span class=faint>0</span>"}</td></tr>')
    body = (head + f'<div class=page><div class=panel><div class=panel-b style="font-size:13px;color:var(--text)">{BENCH_HELP}</div></div>'
            f'<div class=panel><div class=scroll><table class=tbl><thead><tr><th>Benchmark</th><th>Where</th><th>Arms: pass rate, 95% interval, Δ</th>'
            f'<th class=r>Flaky</th></tr></thead><tbody>{"".join(rows)}</tbody></table></div></div></div>')
    return shell(f"Benchmarks · {ctx.p['title']}", body, active="projects", snav=snav(ctx, "bench"))


def benchmark_page(ctx: Ctx, bid: str) -> str | None:
    r = next((b for b in ctx.benches if str(b["id"]) == str(bid)), None)
    if r is None:
        return None
    b = ctx.store.bench(r["id"]) or {}
    arms, meta = b.get("arms", {}), b.get("arms_meta", {})
    titles = b.get("case_titles", {})
    right = (f'<a class=btn href="{e(r["ci_url"])}" target=_blank rel=noopener>{icon("external")}CI run</a>' if r["ci_url"] else "")
    head = page_head([*base_crumbs(ctx.p), ("Benchmarks", f"{purl(ctx.key)}/benchmarks"), (f"#{r['id']}", None)], f"Benchmark #{r['id']}",
                     right=right, meta=[_bench_scope(r), f'{r["cases"]} journeys × {r["attempts"]} attempts per arm',
                                        f'<span title="{e(when(r["created"]))}">{ago(r["created"])}</span>'])
    arm_rows = []
    for a, v in arms.items():
        env = " ".join(f'{e(k)}={e(val)}' for k, val in (meta.get(a, {}).get("env") or {}).items())
        med = meta.get(a, {}).get("median_journey_s")
        arm_rows.append(f'<tr><td><b class=ink>{e(a)}</b>{" <span class=chip>baseline</span>" if a == b.get("baseline") else ""}'
                        + (f'<div class=mono style="font-size:11.5px;color:var(--mute)">{env}</div>' if env else "") + '</td>'
                        f'<td class=nw><b class="num big">{_pct(v.get("pass@1"))}</b></td>'
                        f'<td style="min-width:220px">{_cibar(v, wide=True)}<div class=faint style="font-size:11.5px">{_pct(v["ci95"][0])}–{_pct(v["ci95"][1])}</div></td>'
                        f'<td class=r>{_pct(v.get("pass^k"))}</td><td class=nw>{_delta(v.get("diff_vs_baseline"), b.get("baseline"))}</td>'
                        f'<td class=r>{len(v.get("flaky", [])) or "<span class=faint>0</span>"}</td>'
                        f'<td class="r nw">{"—" if med is None else f"{med:.1f} s"}</td></tr>')
    icons = {"PASS": "PASS", "FAIL": "FAIL", "INCONCLUSIVE": "INCONCLUSIVE"}
    case_rows = []
    flaky_any = {c for v in arms.values() for c in v.get("flaky", [])}
    order = sorted(b.get("per_case", {}), key=lambda c: (c not in flaky_any, c))
    for cid in order:
        row = b["per_case"][cid]
        cells = []
        for a in arms:
            vs = row.get(a, [])
            npass = sum(x == "PASS" for x in vs)
            dots = "".join(f'<i class="{icons.get(x, "")}" title="attempt {k + 1}: {e(x)}"></i>' for k, x in enumerate(vs))
            cells.append(f'<td class=nw><span class=dots>{dots}</span> <span class="num {"mute" if npass == len(vs) else ""}">{npass}/{len(vs)}</span></td>')
        case_rows.append(f'<tr><td><span class=ink>{e(titles.get(cid) or cid)}</span>'
                         f'{" <span class=\"chip warn\">flaky</span>" if cid in flaky_any else ""}<div class=mono style="font-size:11.5px;color:var(--mute)">{e(cid)}</div></td>'
                         + "".join(cells) + '</tr>')
    body = (head + '<div class=page>'
            f'<div class=panel><div class=panel-h><h2>{icon("flask")} Arms</h2></div><div class=scroll><table class=tbl><thead><tr>'
            '<th>Arm</th><th>Pass rate</th><th>95% interval</th><th class=r>All attempts pass</th><th>Δ vs baseline</th><th class=r>Flaky</th>'
            f'<th class=r>Median journey</th></tr></thead><tbody>{"".join(arm_rows)}</tbody></table></div>'
            f'<div class=panel-b style="font-size:12.5px;color:var(--mute);border-top:1px solid var(--border)">{BENCH_HELP}</div></div>'
            f'<div class=panel><div class=panel-h><h2>{icon("journey")} Journeys</h2><span class=mute style="font-size:12.5px">one dot per attempt; flaky first</span></div>'
            '<div class=scroll><table class=tbl><thead><tr><th>Journey</th>' + "".join(f'<th>{e(a)}</th>' for a in arms)
            + f'</tr></thead><tbody>{"".join(case_rows)}</tbody></table></div></div></div>')
    return shell(f"Benchmark #{r['id']} · {ctx.p['title']}", body, active="projects", snav=snav(ctx, "bench"))


def gate_page(ctx: Ctx) -> str:
    main = ctx.store.latest(ctx.key, branch=ctx.p["default_branch"])
    pr_row = next((r for r in ctx.rows if r["pr"]), None)
    gm = (analysis(ctx.store, main["id"]) or {}).get("gate") if main else None
    gp = (analysis(ctx.store, pr_row["id"]) or {}).get("gate") if pr_row else None
    body = (page_head([*base_crumbs(ctx.p), ("Quality gate", None)], "Quality gate",
                      meta=["Defined in <span class=mono>.assay/assay.yaml</span> (<span class=mono>gate:</span>); "
                            "a gate in the server's <span class=mono>server.yaml</span> overrides it"])
            + f'<div class=page><div class=grid style="grid-template-columns:repeat(2,minmax(0,1fr))">'
            f'<div class=panel><div class=panel-h><h2>{icon("pr")} On pull requests: new code</h2>{gate(pr_row["status"]) if pr_row else ""}</div>'
            f'<div class=panel-b style="padding:0">{_cond_table(gp)}</div><div class=panel-b class=mute style="font-size:13px;color:var(--mute)">'
            f'A pull request fails only for what it breaks: journeys that pass on the target branch and fail here, and new issues above the limits. '
            f'Old failures stay visible but never block someone else\'s change.</div></div>'
            f'<div class=panel><div class=panel-h><h2>{icon("branch")} On {e(ctx.p["default_branch"])}: release readiness</h2>{gate(main["status"]) if main else ""}</div>'
            f'<div class=panel-b style="padding:0">{_cond_table(gm)}</div><div class=panel-b style="font-size:13px;color:var(--mute)">'
            f'The main branch answers a different question, whether it can ship, so every failing journey counts. '
            f'Inconclusive means the environment broke: rerun, never ship on it.</div></div></div>'
            f'<div class=panel style="margin-top:20px"><div class=panel-h><h2>How the gate is configured</h2></div><div class=panel-b>'
            f'<pre class=code>{e(GATE_YAML)}</pre></div></div></div>')
    return shell(f"Quality gate · {ctx.p['title']}", body, active="projects", snav=snav(ctx, "gate"))


GATE_YAML = """# .assay/assay.yaml
gate:
  fail_on_case_fail: true            # pull requests: no journey may start failing; branches: none may fail
  max_new: {blocker: 0, critical: 0} # new issues allowed per severity
  min_rating: {reliability: B}       # optional: worst rating allowed per quality, on new code
  max_inconclusive: 0.2              # above this share the gate is INCONCLUSIVE: fix the stand, rerun"""


ACTION = "RazinAleksandr/assay@v0"
REPO_URL = "https://github.com/RazinAleksandr/assay"     # public: the action, the Claude Code plugin, the built scanner
PLUGIN_CMDS = """/plugin marketplace add RazinAleksandr/assay
/plugin install assay@assay
/assay:connect"""


def wheel_url() -> str:
    """The scanner this server was built with, as published in the public repo (CI and the plugin use the same file)."""
    from .. import __version__
    return f"{REPO_URL}/raw/v0/dist/assay-{__version__}-py3-none-any.whl"


def workflow_yaml(public: str) -> str:
    """The GitHub Actions workflow that connects a repository. The action's default server is the public service."""
    from ..access import PUBLIC_SERVER
    with_host = "" if public.rstrip("/") == PUBLIC_SERVER else f"\n        with:\n          host-url: {public}"
    return f"""# .github/workflows/assay.yml
name: Assay
on:
  push:
    branches: [main]
  pull_request:
jobs:
  assay:
    runs-on: ubuntu-latest
    permissions:
      contents: read
      pull-requests: write   # the gate comment
      id-token: write        # sign-in: no token needed
    steps:
      - uses: actions/checkout@v4
      - run: npm ci          # install your app
      - uses: {ACTION}{with_host}"""


def bench_yaml() -> str:
    """The second workflow, for products with AI: repeat the journeys, compare arms (here: two models)."""
    return f"""# .github/workflows/assay-bench.yml
name: Assay benchmark
on:
  workflow_dispatch:
  schedule: [{{cron: "0 6 * * 1"}}]   # weekly
jobs:
  bench:
    runs-on: ubuntu-latest
    permissions: {{contents: read, id-token: write}}
    steps:
      - uses: actions/checkout@v4
      - run: npm ci
      - uses: {ACTION}
        with:
          command: bench
          anthropic-api-key: ${{{{ secrets.ANTHROPIC_API_KEY }}}}
          args: >-
            --attempts 3
            --arm sonnet=env:ASSISTANT_MODEL=sonnet
            --arm haiku=env:ASSISTANT_MODEL=haiku"""


def copyable(text: str) -> str:
    return (f'<div class=copywrap><button type=button class="btn sm copy" data-copy>{icon("copy")}Copy</button>'
            f'<pre class=code>{e(text)}</pre></div>')


def setup_page(store, key: str | None, public: str, ctx: Ctx | None = None, badge_tok: str | None = None) -> str:
    gl = """# .gitlab-ci.yml
include:
  - remote: """ + REPO_URL + """/raw/v0/ci/assay.gitlab-ci.yml
variables:
  ASSAY_HOST_URL: """ + public + """
# ASSAY_TOKEN: the server's admin token, as a masked CI/CD variable"""
    other = f"""docker run --rm -v "$PWD:/src" -w /src \\
  -e ASSAY_HOST_URL={public} -e ASSAY_TOKEN \\
  assay:0.3 ci"""
    owner = key.split("/")[1] if key and key.startswith("gh/") else None
    badge_src = f"{public}/api/projects/{key}/badge.svg" + (f"?token={badge_tok}" if badge_tok and ctx and ctx.p["visibility"] == "private" else "")
    badge = f"[![Assay]({badge_src})]({public}{purl(key)})" if key else ""
    steps = (f'<ol class=steps-setup>'
             f'<li><h3>Ask Claude Code to connect it</h3><p class=mute style="margin-bottom:8px">In the repository, in Claude Code: install the plugin and run '
             f'<span class=mono>/assay:connect</span>. Claude reads the app, writes <span class=mono>.assay/</span> with 5-10 journeys, proves them on the '
             f'running app, adds the workflow below and opens the pull request. About 30 minutes, without you.</p>'
             f'{copyable(PLUGIN_CMDS)}'
             f'<details class=byhand><summary>Or by hand</summary><p class=mute style="margin:8px 0">'
             f'<span class=mono>assay init</span> writes <span class=mono>.assay/</span> with a start command and one journey, and the workflow. '
             f'Then edit <span class=mono>assay.yaml</span> and add journeys (<a href="{REPO_URL}/blob/v0/docs/AUTHORING.md">format</a>).</p>'
             f'{copyable(f"uvx --from {wheel_url()} assay init")}</details></li>'
             f'<li><h3>The CI step it adds</h3><div class=panel style="margin-top:8px"><div class=tabs data-tabs=ci>'
             f'<button data-tab=gh class=on>GitHub Actions</button><button data-tab=gl>GitLab CI</button><button data-tab=other>Other CI</button></div>'
             f'<div class=tabpane data-pane="ci:gh" style="padding:14px">{copyable(workflow_yaml(public))}'
             f'<p class=mute style="margin-top:10px">No sign-up and no secrets. <span class=mono>id-token: write</span> lets GitHub vouch for the job, '
             f'so it can only write to its own repository\'s project.</p></div>'
             f'<div class=tabpane data-pane="ci:gl" hidden style="padding:14px">{copyable(gl)}</div>'
             f'<div class=tabpane data-pane="ci:other" hidden style="padding:14px">{copyable(other)}</div></div></li>'
             f'<li><h3>For AI features, add the benchmark</h3><p class=mute style="margin-bottom:8px">A model answers differently every time, '
             f'so one green run proves little. A second workflow repeats every journey and compares arms: two models, two prompts, '
             f'two builds. Each arm reports its pass rate with a 95% interval and the journeys that flip.</p>{copyable(bench_yaml())}</li>'
             f'<li><h3>Open a pull request</h3><p class=mute>The first analysis creates '
             + (f'the account <a href="/gh/{e(owner)}">{e(owner)}</a> and this project.' if owner else 'your account (named after the GitHub owner) and the project.')
             + ' The pull request gets the gate and a link to the evidence. Private repositories stay private: '
             'their analyses open only from that link.</p>'
             + (f'<div style="margin-top:12px;display:flex;gap:12px;align-items:center;flex-wrap:wrap"><img src="{e(badge_src.replace(public, ""))}" alt="badge">'
                f'<span class=mono style="font-size:12px;overflow-wrap:anywhere">{e(badge)}</span></div>' if key else "")
             + '</li></ol>')
    head = (page_head([*base_crumbs(ctx.p), ("Set up CI", None)], "Set up CI") if ctx else
            page_head([("Connect a repository", None)], "Connect a repository", meta=["one CI step; the first analysis creates your account and project"]))
    body = head + f'<div class=page><div class=panel><div class=panel-b style="padding:24px 26px 6px">{steps}</div></div></div>'
    return shell("Set up CI", body, active="projects", snav=snav(ctx, "setup") if ctx else None)


EXAMPLE_COMMENT = """<div class=ghc aria-label="Example: the comment Assay posts on a pull request">
<div class=ghc-h><span class=ghc-av>{bot}</span><b>github-actions</b><span class=ghc-bot>bot</span><span class=mute>commented</span></div>
<div class=ghc-b>
<div class=ghc-t><span class="gate FAILED"><span class=sq>{x}</span></span>Assay quality gate: <b>FAILED</b></div>
<p class=mute>Morrow — social app · pull request #2 → <span class=mono>main</span></p>
<p><b>New code</b> compared with <span class=mono>main</span>: 1 newly failing journey · 0 fixed · 2 new issues</p>
<table><tr><th>Condition</th><th>Actual</th><th>Allowed</th></tr>
<tr class=bad><td>New failed journeys</td><td>1</td><td>= 0</td></tr>
<tr><td>New blocker issues</td><td>0</td><td>≤ 0</td></tr>
<tr><td>New critical issues</td><td>0</td><td>≤ 0</td></tr></table>
<p><b>Newly failing:</b> Mila comments on Noah's post — the database got
<span class=mono>"QA kind words dc61a5"</span>, the journey typed a 90-character comment.</p>
<p class=ghc-link>See the analysis on Assay {arrow}</p>
</div></div>"""


def landing_page(store, viewer, public: str) -> str:
    projects, allrows = visible(store, viewer)
    cards, _, _ = project_cards(store, projects[:6], [r for r in allrows if r["project"] in {p["key"] for p in projects[:6]}])
    comment = EXAMPLE_COMMENT.format(bot=icon("check"), x=icon("x"), arrow=icon("arrow"))
    checks = [
        ("journey", "Journeys, checked against the data",
         "A journey is what a person does: log in, post, pay. Assay walks it in Chromium or WebKit and then reads the app's real "
         "state: a comment adds exactly one row with the full text, and nothing else changes."),
        ("screens", "Every screen, scanned",
         "Console errors and failed requests, Core Web Vitals, WCAG 2.2 AA, layout overflow, touch targets, broken images, "
         "tokens left in storage. Findings become issues with ratings from A to E."),
        ("gate", "A verdict with an owner",
         "Pass, fail or inconclusive. A failure names the step, the screenshot and the difference in the data. A broken "
         "environment is inconclusive and never blocks a merge."),
        ("flask", "Benchmarks for AI features",
         "Models answer differently every run. A second workflow repeats the journeys and compares models, prompts or "
         "builds: a pass rate with its 95% interval per arm, and the journeys that flip."),
    ]
    body = (
        '<div class=lp>'
        '<section class=lp-hero><div class=lp-copy>'
        '<h1>The quality gate for the running app</h1>'
        '<p class=lead>Assay starts your app in CI, walks through it the way people use it, and checks what really got saved. '
        'Every pull request gets a verdict, and every verdict links to its evidence.</p>'
        f'<div class=lp-cta><a class="btn primary" href="/setup">{icon("plus")}Connect a repository</a>'
        f'<a class=btn href="/docs">How it works</a></div>'
        '<p class="mute sm">For GitHub repositories. The first analysis creates your account: no sign-up, no tokens.</p>'
        f'</div><div class=lp-demo>{comment}</div></section>'
        '<section class=lp-sec><div class=lp-two><div><h2>Connect in one prompt</h2>'
        '<ol class=lp-steps><li><b>Install the Claude Code plugin</b> in your app\'s repository.</li>'
        '<li><b>Run <span class=mono>/assay:connect</span>.</b> Claude reads the app, writes 5-10 journeys, proves them on the '
        'running app and opens a pull request with the workflow.</li>'
        '<li><b>Merge it.</b> Every pull request after that gets the gate, and the evidence appears here.</li></ol></div>'
        f'<div class=lp-code>{copyable(PLUGIN_CMDS)}</div></div></section>'
        '<section class=lp-sec><h2>What every analysis checks</h2><div class=lp-three>'
        + "".join(f'<div><span class=lp-ic>{icon(ic)}</span><h3>{t}</h3><p>{d}</p></div>' for ic, t, d in checks)
        + '</div></section>'
        + (f'<section class=lp-sec><div class=lp-sh><h2>{"Your projects" if any((p["visibility"] or "public") == "private" for p in projects) else "Projects"}</h2>'
           f'<a href="/projects">All projects {icon("arrow")}</a></div><div class=pcards>{"".join(cards)}</div></section>' if cards else "")
        + '</div>')
    return shell("The quality gate for the running app", body, active="home")


def login_page(failed: bool = False) -> str:
    body = ('<div class=page><div class="panel narrow"><div class=panel-b style="padding:26px">'
            '<h1 style="margin-bottom:6px">Sign in</h1><p class=mute style="margin-bottom:16px">The admin sees every project. '
            'Anyone else opens a private project from the link Assay posts in its pull request.</p>'
            + ('<p class="chip fail" style="margin-bottom:12px">Wrong login or password.</p>' if failed else "")
            + '<form method=post action="/login" class=loginf>'
            '<label for=user>Login</label><input class=input id=user name=user value=admin autocomplete=username required>'
            '<label for=password>Password</label><input class=input id=password type=password name=password autocomplete=current-password required>'
            '<button class="btn primary" type=submit>Sign in</button></form>'
            '<p class=mute style="margin-top:14px;font-size:13px"><a href="/logout">Sign out</a></p>'
            '</div></div></div>')
    return shell("Sign in", body)


def not_found_page(message: str = "not found") -> str:
    body = (f'<div class=page><div class="panel narrow"><div class=panel-b style="padding:26px">'
            f'<h1 style="margin-bottom:6px">Not found</h1><p class=mute>{e(message[:1].upper() + message[1:])}</p>'
            f'<p style="margin-top:14px"><a href="/">Home</a> · <a href="/projects">Projects</a> · <a href="/setup">Connect a repository</a></p>'
            f'</div></div></div>')
    return shell("Not found", body)


def rules_page(store, viewer=None) -> str:
    projects, allrows = visible(store, viewer)
    seen = Counter()
    for m in _latest_by_project(projects, allrows)[0].values():
        for i in (analysis(store, m["id"]) or {}).get("issues", []):
            seen[i["rule"].split("-")[0] + "-" + i["rule"].split("-")[1] if i["rule"].startswith("A11Y-") else i["rule"]] += 1
    rows = []
    allrules = dict(RULES)
    allrules.setdefault("A11Y", ("Accessibility violation (axe-core rule, WCAG 2.2 AA): one rule per axe check", "accessibility"))
    for rid, (title, dim) in allrules.items():
        n = sum(v for k, v in seen.items() if k == rid or (rid == "A11Y" and k.startswith("A11Y-")))
        rows.append(f'<tr data-item data-dim="{e(dim)}" data-text="{e((rid + " " + title).lower())}"><td class=mono style="white-space:nowrap">{e(rid)}</td>'
                    f'<td class=ink>{e(title)}</td><td>{e(DIM_SHORT.get(dim, dim))}</td><td class=r>{n or "<span class=faint>0</span>"}</td></tr>')
    fac = '<div class=facet><h4>Quality</h4>' + "".join(
        f'<button type=button data-facet=dim data-value="{d}">{e(DIM_SHORT[d])}<span class=n>{sum(1 for r in allrules.values() if r[1] == d)}</span></button>' for d in DIM_SHORT) + '</div>'
    body = (page_head([("Rules", None)], "Rules", meta=[f"{len(allrules)} rules", "sensors run on every journey and every scanned screen; journeys add their own checks"])
            + f'<div class=page data-filter-root><div class=withfacets><aside class=facets>{fac}</aside><div><div class=toolbar>'
            f'<input class=input data-search placeholder="Search rules" style="width:260px"><div class=r><span class=count><b data-shown>{len(rows)}</b> rules</span></div></div>'
            f'<div class=panel><table class=tbl><thead><tr><th>Rule</th><th>What it finds</th><th>Quality</th><th class=r>Open on main branches</th></tr></thead>'
            f'<tbody data-filter-list>{"".join(rows)}</tbody></table></div></div></div></div>')
    return shell("Rules", body, active="rules")


def gates_page(store, config: dict) -> str:
    srv = config.get("gate")
    per = config.get("projects") or {}
    body = (page_head([("Quality gates", None)], "Quality gates", meta=["the default is defined per repository; the server can enforce one for everybody"])
            + f'<div class=page><div class=panel><div class=panel-h><h2>{icon("gate")} Assay way</h2><span class="chip brand">Default</span></div>'
            f'<div class=panel-b><p style="margin-bottom:12px">Pull requests are gated on <b>new code</b>: no journey may start failing, no new blocker or critical issue. '
            f'Branches are gated on <b>release readiness</b>: no journey may fail. More than 20% inconclusive journeys makes the gate inconclusive '
            f'(the stand broke, not the product).</p><pre class=code>{e(GATE_YAML)}</pre></div></div>'
            f'<div class=panel><div class=panel-h><h2>Server-enforced gate</h2></div><div class=panel-b>'
            + (f'<pre class=code>{e(json.dumps(srv, indent=1))}</pre>' if srv else '<p class=mute>None. Start the server with <span class=mono>--config server.yaml</span> '
               'and a <span class=mono>gate:</span> block to enforce one for every project, or <span class=mono>projects.&lt;key&gt;.gate</span> for one.</p>')
            + (''.join(f'<div class=mono style="margin-top:8px">{e(k)}: {e(json.dumps(v.get("gate")))}</div>' for k, v in per.items()) if per else '')
            + '</div></div></div>')
    return shell("Quality gates", body, active="gates")


def docs_page() -> str:
    flow = [("Pull request", "a push to main or a pull request starts the job"),
            ("Start the app", "the command from .assay/assay.yaml, on a fresh copy of its data"),
            ("Walk the journeys", "in Chromium or WebKit, desktop or phone, step by step or toward a goal"),
            ("Read the state", "the app's database, API, storage or canvas before and after each journey"),
            ("Compare with main", "only what this pull request breaks can block it"),
            ("Report", "a comment on the pull request, the evidence here")]
    verdicts = [("PASS", "pass", "every required check held: the steps ran and the data changed exactly as expected"),
                ("FAIL", "fail", "the product is at fault: the page names the step, shows its screenshot and the data that differs"),
                ("INCONCLUSIVE", "warn", "the environment is at fault (the app did not start, no model for an AI check); it never blocks a merge")]
    body = (page_head([("How Assay works", None)], "How Assay works",
                      meta=["a quality gate for the running app, in the shape of SonarQube: one CI step, a gate on each pull request, the evidence on this site"])
            + '<div class=page><div class=panel><div class=panel-b style="padding:22px 24px"><ol class=howflow>'
            + "".join(f'<li><b>{t}</b><span>{d}</span></li>' for t, d in flow)
            + '</ol></div></div><div class=grid style="grid-template-columns:repeat(3,minmax(0,1fr));margin-top:16px">'
            + "".join(f'<div class=panel><div class=panel-h><h2><span class="chip {c}">{v}</span></h2></div><div class=panel-b style="font-size:13.5px">{d}</div></div>'
                      for v, c, d in verdicts)
            + '</div><div class=grid style="grid-template-columns:repeat(3,minmax(0,1fr));margin-top:16px">'
            + "".join(f'<div class=panel><div class=panel-h><h2>{icon(ic)} {t}</h2></div><div class=panel-b style="font-size:13.5px">{d}</div></div>' for ic, t, d in (
                ("journey", "Journeys", "What a person does, a few lines of YAML each: steps, or a goal an AI agent walks once and CI replays. "
                 "Checks read the app's data: a like adds exactly one like and nothing else changes."),
                ("screens", "Every screen", "Exceptions, console errors and failed requests, Core Web Vitals, WCAG 2.2 AA, overflow, touch targets, "
                 "broken images, tokens in storage. Each finding is an issue with a rating from A to E."),
                ("gate", "The gate", "Pull requests: no journey may start failing and no new blocker or critical issue. "
                 "Branches: no journey may fail. Too many inconclusive journeys make the gate inconclusive."),
            )) + '</div><p class=mute style="margin-top:18px"><a href="/setup">Connect a repository</a> · '
            '<a href="/rules">Rules</a> · <a href="/quality-gates">Quality gates</a></p></div>')
    return shell("How Assay works", body)
