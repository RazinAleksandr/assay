// Assay server UI: tabs, facet filters, expandable issues, screenshot lightbox. No framework, no build step.
(function () {
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));

  // tabs: <div class=tabs data-tabs=x><button data-tab=a>…</button></div> + <div class=tabpane data-pane="x:a">
  $$('[data-tabs]').forEach(bar => {
    const group = bar.dataset.tabs;
    const show = id => {
      $$('[data-tab]', bar).forEach(b => b.classList.toggle('on', b.dataset.tab === id));
      $$(`[data-pane^="${group}:"]`).forEach(p => { p.hidden = p.dataset.pane !== `${group}:${id}`; });
    };
    $$('[data-tab]', bar).forEach(b => b.addEventListener('click', () => show(b.dataset.tab)));
  });

  // facet filtering: container [data-filter-list] with items carrying data-<facet>="value" (space separated)
  $$('[data-filter-root]').forEach(root => {
    const list = root.querySelector('[data-filter-list]');
    const items = $$('[data-item]', list);
    const groups = $$('[data-group]', list);
    const counter = root.querySelector('[data-shown]');
    const search = root.querySelector('[data-search]');
    const active = {};
    const apply = () => {
      const q = (search && search.value || '').trim().toLowerCase();
      let shown = 0;
      items.forEach(it => {
        let ok = Object.entries(active).every(([k, v]) => !v || (it.dataset[k] || '').split(' ').includes(v));
        if (ok && q) ok = (it.dataset.text || it.textContent).toLowerCase().includes(q);
        it.hidden = !ok;
        if (ok) shown++;
      });
      groups.forEach(g => { g.hidden = !$$('[data-item]', g).some(i => !i.hidden); });
      if (counter) counter.textContent = shown;
    };
    $$('[data-facet]', root).forEach(btn => btn.addEventListener('click', () => {
      const k = btn.dataset.facet, v = btn.dataset.value;
      active[k] = active[k] === v ? '' : v;
      $$(`[data-facet="${k}"]`, root).forEach(b => b.classList.toggle('on', active[k] === b.dataset.value));
      apply();
    }));
    if (search) search.addEventListener('input', apply);
    const sort = root.querySelector('[data-sort]');
    if (sort) sort.addEventListener('change', () => {
      const key = sort.value;
      const parent = items[0] && items[0].parentElement;
      if (!parent || groups.length) return;
      items.sort((a, b) => (key === 'name') ? a.dataset.name.localeCompare(b.dataset.name)
        : (Number(b.dataset[key] || 0) - Number(a.dataset[key] || 0))).forEach(i => parent.appendChild(i));
    });
    apply();
  });

  // issues: click to expand evidence
  $$('.issue-m').forEach(m => m.addEventListener('click', e => {
    if (e.target.closest('a')) return;
    const card = m.closest('.issue'), x = card.querySelector('.issue-x');
    if (!x) return;
    x.hidden = !x.hidden;
    card.classList.toggle('open', !x.hidden);
    $$('img[data-src]', x).forEach(img => { img.src = img.dataset.src; img.removeAttribute('data-src'); });
  }));

  // lightbox for screenshots
  const lb = document.getElementById('lb');
  if (lb) {
    document.addEventListener('click', e => {
      const img = e.target.closest('img[data-zoom]');
      if (img) { lb.querySelector('img').src = img.dataset.zoom || img.src; lb.hidden = false; }
      else if (e.target.closest('#lb')) lb.hidden = true;
    });
    document.addEventListener('keydown', e => { if (e.key === 'Escape') lb.hidden = true; });
  }

  // close open selectors when clicking elsewhere
  document.addEventListener('click', e => {
    $$('details.sel[open]').forEach(d => { if (!d.contains(e.target)) d.open = false; });
  });
})();

// copy buttons next to code blocks
document.addEventListener("click", (ev) => {
  const b = ev.target.closest("[data-copy]");
  if (!b) return;
  const pre = b.parentElement.querySelector("pre");
  const label = b.lastChild;
  navigator.clipboard.writeText(pre.innerText).then(() => {
    label.textContent = "Copied";
    setTimeout(() => { label.textContent = "Copy"; }, 1500);
  }).catch(() => {
    const r = document.createRange(); r.selectNodeContents(pre);
    const s = getSelection(); s.removeAllRanges(); s.addRange(r);
  });
});

// the Issues page opened for one quality (?dim=): select that facet
document.addEventListener("DOMContentLoaded", () => {
  const root = document.querySelector("[data-predim]");
  const dim = root && root.dataset.predim;
  if (!dim) return;
  const b = document.querySelector(`[data-facet="dim"][data-value="${CSS.escape(dim)}"]`);
  if (b) { b.classList.remove("on"); b.click(); }
});
