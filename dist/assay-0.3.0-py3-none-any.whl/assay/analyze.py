"""Analysis: a run folder (evidence only) → analysis.json (verdicts, issues, ratings, gate, coverage).

Pure function of the evidence + judge cache, so `assay grade <run>` reproduces it exactly.
"""
from __future__ import annotations

import json
import time
from pathlib import Path

from .config import Profile
from .grade import grade_case
from .judge import Judge
from .model import FAIL, INCONCLUSIVE, PASS
from .quality import case_changes, coverage, gate, load_baseline, mark_new, ratings
from .rules import case_issues, merge, route_of, sensor_issues


def analyze(run_dir: Path, profile: Profile, *, judge: Judge | None, baseline: Path | None = None,
            log=print) -> dict:
    run_dir = Path(run_dir)
    run_meta = json.loads((run_dir / "run.json").read_text()) if (run_dir / "run.json").exists() else {}
    evs = []
    for f in sorted((run_dir / "cases").glob("*/evidence.json")) if (run_dir / "cases").exists() else []:
        evs.append((f.parent, json.loads(f.read_text())))
    order = {cid: i for i, cid in enumerate(run_meta.get("case_order", []))}
    evs.sort(key=lambda x: order.get(x[1]["case_id"], 10_000))

    results, issues = [], []
    case_routes: list[str] = []
    for case_dir, ev in evs:
        res = grade_case(ev, case_dir, volatile=profile.volatile, judge=judge)
        shot = f"cases/{case_dir.name}/{ev['final_screenshot']}" if ev.get("final_screenshot") else ""
        d = res.to_dict()
        if (ev.get("final_url") or "about:blank") == "about:blank":
            shot = ""          # API-only journey: there is no screen to show
        d.update(screenshot=shot, final_url=ev.get("final_url"), account=ev.get("account"), viewport=ev.get("viewport"), browser=ev.get("browser"),
                 steps=[{k: s.get(k) for k in ("i", "action", "summary", "ok", "error", "ms", "screenshot")}
                        for s in ev.get("steps", [])],
                 tags=(ev.get("case") or {}).get("tags", []), error=ev.get("error"))
        results.append(d)
        issues += case_issues(res, shot)
        issues += sensor_issues(ev, source=ev["case_id"], evidence_path=shot)
        case_routes += [route_of(u) for u in (ev.get("sensors") or {}).get("urls", [])]
        if judge:
            judge.save()

    pages = []
    pages_file = run_dir / "scan" / "pages.json"
    if pages_file.exists():
        pages = json.loads(pages_file.read_text())
        for p in pages:
            issues += sensor_issues(p, source=f"scan:{p['viewport']}:{p['route']}", evidence_path=p.get("screenshot", ""),
                                    page_mode=True)

    import fnmatch
    ignored = profile.ignore.get("rules", [])
    issues = [i for i in issues if not any(fnmatch.fnmatch(i.rule, pat) for pat in ignored)]
    merged = merge(issues)
    base = load_baseline(baseline) if baseline else None
    mark_new(merged, base)
    r_all, r_new = ratings(merged), ratings(merged, only_new=True)
    g = gate(profile.gate, results, merged, r_new if base else r_all, baseline=base)

    n = len(results)
    counts = {v: sum(r["verdict"] == v for r in results) for v in (PASS, FAIL, INCONCLUSIVE)}
    sev_counts: dict[str, int] = {}
    for i in merged:
        sev_counts[i.severity] = sev_counts.get(i.severity, 0) + 1
    dims: dict[str, dict] = {}
    for i in merged:
        d = dims.setdefault(i.dimension, {"issues": 0, "new": 0})
        d["issues"] += 1
        d["new"] += int(i.new)
    analysis = {
        "run": run_meta, "ci": run_meta.get("ci"), "app": {"name": profile.name, "title": profile.title, "base_url": profile.base_url},
        "generated": time.strftime("%Y-%m-%d %H:%M:%S"), "baseline": _baseline_label(baseline, base),
        "summary": {"cases": n, **counts, "pass_rate": round(counts[PASS] / max(1, n - counts[INCONCLUSIVE]), 3) if n else None,
                    "issues": len(merged), "new_issues": sum(i.new for i in merged), "by_severity": sev_counts,
                    "pages_scanned": len(pages), "routes_scanned": len({p["route"] for p in pages})},
        "gate": g, "ratings": r_all, "ratings_new": r_new if base else None, "dimensions": dims,
        "cases": results, "issues": [i.to_dict() for i in merged],
        "pages": [{k: p.get(k) for k in ("url", "route", "viewport", "browser", "status", "screenshot", "load_s", "error")}
                  | {"a11y": len(((p.get("audit") or {}).get("a11y") or {}).get("violations", [])),
                     "vitals": (p.get("audit") or {}).get("vitals"), "timing": (p.get("audit") or {}).get("timing")}
                  for p in pages],
        "coverage": coverage([p["route"] for p in pages], case_routes) if pages else None,
        "changes": case_changes(results, base),
        "judge": {"backend": judge.backend if judge else None, "model": judge.model if judge else None,
                  "calls": judge.calls if judge else 0, "cost_usd": round(judge.cost_usd, 4) if judge else 0},
    }
    (run_dir / "analysis.json").write_text(json.dumps(analysis, indent=1, ensure_ascii=False, default=str))
    return analysis


def _baseline_label(baseline, base: dict | None) -> str | None:
    """Short name of what this analysis was compared with: a run folder, or a server analysis (branch @ commit)."""
    if not baseline:
        return None
    if isinstance(baseline, dict):
        ci = (base or {}).get("ci") or {}
        ref = ci.get("branch") or (base or {}).get("run", {}).get("id", "")
        return f"{ref} @ {ci['sha'][:7]}" if ci.get("sha") else str(ref)
    return str(baseline)
