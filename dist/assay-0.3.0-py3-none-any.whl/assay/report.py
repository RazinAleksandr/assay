"""Reports: report.html (dashboard), report.md (PR/MR comment), junit.xml (CI test tab)."""
from __future__ import annotations

import html
import json
from pathlib import Path
from xml.sax.saxutils import escape as xesc

from .model import DIMENSIONS

RATING_COLOR = {"A": "#1f9d55", "B": "#7cb342", "C": "#f2b705", "D": "#f07c1f", "E": "#d93025"}
SEV_ICON = {"blocker": "⛔", "critical": "🔴", "major": "🟠", "minor": "🟡", "info": "⚪"}
VERDICT_ICON = {"PASS": "✅", "FAIL": "❌", "INCONCLUSIVE": "⚠️"}
GATE_ICON = {"PASSED": "✅", "FAILED": "❌", "INCONCLUSIVE": "⚠️"}


def write_all(run_dir: Path, a: dict) -> None:
    (run_dir / "report.md").write_text(markdown(a))
    (run_dir / "junit.xml").write_text(junit(a))
    (run_dir / "report.html").write_text(dashboard(a))


# ---- markdown ---------------------------------------------------------------------

def markdown(a: dict) -> str:
    s, g = a["summary"], a["gate"]
    r = a.get("ratings_new") or a["ratings"]
    lines = [f"## {GATE_ICON[g['status']]} Quality gate {g['status']} — {a['app'].get('title') or a['app']['name']}",
             "",
             f"**Journeys:** {s['PASS']} pass · {s['FAIL']} fail · {s['INCONCLUSIVE']} inconclusive"
             f" · **Issues:** {s['issues']} ({s['new_issues']} new) · **Screens scanned:** {s['pages_scanned']}",
             "",
             "| " + " | ".join(DIMENSIONS.values()) + " |",
             "|" + "---|" * len(DIMENSIONS),
             "| " + " | ".join(f"**{r[d]}**" for d in DIMENSIONS) + " |",
             "", "| Condition | Actual | Threshold | |", "|---|---|---|---|"]
    for c in g["conditions"]:
        lines.append(f"| {c['name']} | {c['actual']} | {c['op']} {c['threshold']} | {'✅' if c['ok'] else '❌'} |")
    bad = [c for c in a["cases"] if c["verdict"] != "PASS"]
    if bad:
        lines += ["", "### Journeys that need attention", "", "| | Case | Owner | Why |", "|---|---|---|---|"]
        for c in bad:
            lines.append(f"| {VERDICT_ICON[c['verdict']]} | `{c['case_id']}` {c['title']} | {c['owner']} | {_md(c['summary'])[:220]} |")
    top = [i for i in a["issues"] if i["severity"] in ("blocker", "critical", "major")][:15]
    if top:
        lines += ["", "### Top issues", "", "| Sev | Rule | Where | Message | Seen |", "|---|---|---|---|---|"]
        for i in top:
            new = " 🆕" if i.get("new") and a.get("baseline") else ""
            lines.append(f"| {SEV_ICON[i['severity']]} {i['severity']} | `{i['rule']}` {i['title']}{new} | `{i['where'] or '—'}` "
                         f"| {_md(i['message'])[:160]} | {i['count']}× |")
    ch = a.get("changes") or {}
    if ch.get("regressions") or ch.get("fixed"):
        lines += ["", f"**vs baseline:** regressions {ch.get('regressions')}, fixed {ch.get('fixed')}"]
    cov = a.get("coverage")
    if cov and cov.get("ratio") is not None and a["cases"]:
        lines += ["", f"**App coverage:** {cov['ratio']:.0%} of discovered screens exercised by journeys "
                      f"({len(cov['covered'])}/{len(cov['discovered'])})."]
    lines += ["", f"<sub>assay · run `{a['run'].get('id', '')}` · judge {a['judge']['backend']}/{a['judge']['model']}"
                  f" · {a['judge']['calls']} judge calls</sub>", ""]
    return "\n".join(lines)


def _md(s: str) -> str:
    return (s or "").replace("|", "\\|").replace("\n", " ")


# ---- junit --------------------------------------------------------------------------

def junit(a: dict) -> str:
    cases = a["cases"]
    out = [f'<?xml version="1.0" encoding="UTF-8"?>',
           f'<testsuite name="assay.{xesc(a["app"]["name"])}" tests="{len(cases)}" '
           f'failures="{sum(c["verdict"] == "FAIL" for c in cases)}" skipped="{sum(c["verdict"] == "INCONCLUSIVE" for c in cases)}">']
    for c in cases:
        out.append(f'  <testcase classname="{xesc(a["app"]["name"])}" name="{xesc(c["case_id"])}" time="{c["duration_s"]}">')
        if c["verdict"] == "FAIL":
            out.append(f'    <failure message="{xesc(c["summary"][:300], {chr(34): "&quot;"})}"/>')
        elif c["verdict"] == "INCONCLUSIVE":
            out.append(f'    <skipped message="{xesc(c["summary"][:300], {chr(34): "&quot;"})}"/>')
        out.append("  </testcase>")
    out.append("</testsuite>")
    return "\n".join(out) + "\n"


# ---- html report ----------------------------------------------------------------------

def dashboard(a: dict, header: str | None = None, context: str = "", foot: str | None = None) -> str:
    """The run report. The Assay server passes its own navigation `header`, a `context` block (branch / pull request,
    what it was compared with) and `foot`; the standalone file uses the defaults."""
    from .theme import e, page
    s, g = a["summary"], a["gate"]
    ci = a.get("ci") or {}
    new_code = bool(a.get("ratings_new")) and (bool(ci.get("pr")) or not ci)   # a PR is rated on what it changes
    rat = a["ratings_new"] if new_code else a["ratings"]
    dims = a.get("dimensions", {})
    title = a["app"].get("title") or a["app"]["name"]
    run = a.get("run", {})
    n = s["cases"]
    bad_conds = [c for c in g["conditions"] if not c["ok"] and not c.get("soft")]
    if g["status"] == "PASSED":
        sentence = f"All {n} journeys passed the release minimum and no condition of the gate is violated."
    elif g["status"] == "INCONCLUSIVE":
        sentence = (f"{s['INCONCLUSIVE']} of {n} journeys could not be checked because the environment broke. "
                    "This says nothing about the product: fix the stand and run again.")
    else:
        sentence = "Blocked by: " + "; ".join(f"{c['name'].lower()} {c['actual']} (allowed {c['op']} {c['threshold']})"
                                              for c in bad_conds) + "."
    dur = ""
    try:
        from datetime import datetime
        t0, t1 = datetime.fromisoformat(run["started"]), datetime.fromisoformat(run["finished"])
        dur = f"{(t1 - t0).seconds // 60} min {(t1 - t0).seconds % 60} s"
    except Exception:
        pass
    j = a.get("judge", {})
    out = [header or (f'<header class=bar><div class=logo>assay<span>.</span><small>Run report</small></div>'
           f'<div class=meta>{e(title)} · run {e(run.get("id", ""))} · {e(a["generated"])} · {e(a["app"]["base_url"])}'
           f'{" · baseline " + e(Path(a["baseline"]).name) if a.get("baseline") else ""}</div></header>'), context]
    out.append(f'<section class="verdict {g["status"]}"><div class=label>Quality gate {g["status"].lower()}</div>'
               f'<h1>{e(title)}</h1><p>{e(sentence)}</p></section>')
    bs = s.get("by_severity", {})
    cov = a.get("coverage") or {}
    figs = [(f'{s["PASS"]}<small class=mute style="font-size:16px;font-weight:500"> / {n}</small>', "journeys passed"
             + (f' · {s["FAIL"]} failed' if s["FAIL"] else "") + (f' · {s["INCONCLUSIVE"]} inconclusive' if s["INCONCLUSIVE"] else "")),
            (str(s["issues"]), f'issues: {bs.get("blocker", 0)} blocker, {bs.get("critical", 0)} critical, '
                               f'{bs.get("major", 0)} major, {bs.get("minor", 0)} minor'),
            (str(s["pages_scanned"]), f'screens scanned ({s["routes_scanned"]} routes, desktop and phone)'),
            (f'{cov["ratio"]:.0%}' if cov.get("ratio") is not None and n else (dur or "—"),
             "of scanned screens covered by journeys" if cov.get("ratio") is not None and n else "duration")]
    out.append('<div class=figs>' + "".join(f'<div class=fig><b>{v}</b><span>{e(l)}</span></div>' for v, l in figs) + '</div>')

    # ratings + gate
    rrows = "".join(f'<tr><td>{e(label)}</td><td class=c><span class="sq {rat[d]}">{rat[d]}</span></td>'
                    f'<td class=r>{(str(dims.get(d, {}).get("new", 0)) + " <span class=mute>/ " + str(dims.get(d, {}).get("issues", 0)) + "</span>") if new_code else dims.get(d, {}).get("issues", 0)}</td></tr>'
                    for d, label in DIMENSIONS.items())
    grows = "".join(f'<tr><td>{e(c["name"])}</td><td class=r>{e(c["actual"])}</td><td class="r mute">{e(c["op"])} {e(c["threshold"])}</td>'
                    f'<td class=r><span class="st {"PASS" if c["ok"] else ("INCONCLUSIVE" if c.get("soft") else "FAIL")}">'
                    f'{"met" if c["ok"] else "not met"}</span></td></tr>' for c in g["conditions"])
    out.append(f'<div class=cols><section><h2>Quality ratings{" of the new code" if new_code else ""}</h2><table><thead><tr><th>Dimension</th><th class=c>Rating</th>'
               f'<th class=r>{"New / all issues" if new_code else "Issues"}</th></tr></thead><tbody>{rrows}</tbody></table>'
               '<p class=note style="margin-top:8px">A no issues · B minor · C major · D critical · E blocker. '
               'A rating is set by the most severe issue in its dimension.</p></section>'
               '<section><h2>Gate conditions</h2><table><thead><tr><th>Condition</th><th class=r>Actual</th>'
               f'<th class=r>Allowed</th><th class=r>Result</th></tr></thead><tbody>{grows}</tbody></table></section></div>')

    # journeys that need attention
    bad = [c for c in a["cases"] if c["verdict"] != "PASS"]
    if bad:
        out.append(f'<h2>Journeys that need attention ({len(bad)})</h2>')
        for c in bad:
            failed_step = next((st for st in c.get("steps", []) if not st.get("ok")), None)
            shot = (f'cases/{c["case_id"]}/{failed_step["screenshot"]}' if failed_step and failed_step.get("screenshot")
                    else c.get("screenshot"))
            checks = "".join(
                f'<li><span class="{ {"pass": "ok", "fail": "nok"}.get(it["status"], "und") }">'
                f'{ {"pass": "passed", "fail": "failed", "undecided": "undecided", "skipped": "skipped"}[it["status"]] }</span> '
                f'<b>{e(it["level"])}</b> {e(it["kind"])}{" (AI judge)" if it["by"] == "judge" else ""}'
                f'{": " + e(it["detail"]) if it["detail"] and it["status"] != "pass" else ""}</li>'
                for it in c["items"] if it["status"] != "skipped")
            steps = "".join(f'<li class="{"" if st.get("ok") else "nok"}">{e(st.get("action"))} {e(st.get("summary"))}'
                            f'{" — " + e(st.get("error")) if st.get("error") else ""}</li>' for st in c.get("steps", []))
            img = f'<a href="{e(shot)}"><img loading=lazy src="{e(shot)}" alt="screen at the end of the journey"></a>' if shot else ""
            out.append(f'<article class=case><div><div class="st {c["verdict"]}">{c["verdict"]}</div>'
                       f'<h3>{e(c["title"] or c["case_id"])}</h3>'
                       f'<div class="mono mute">{e(c["case_id"])} · {e(c.get("viewport"))} · {e(c.get("browser"))}'
                       f'{" · as " + e(c["account"]) if c.get("account") else ""} · severity {e(c["severity"])} · owner {e(c["owner"])}</div>'
                       f'<div class="why {c["verdict"]}">{e(c["summary"])}</div>'
                       f'<details><summary>Checks and steps</summary><ul class=checks>{checks}</ul>'
                       f'<ol class=steps start=0>{steps}</ol></details></div><div>{img}</div></article>')

    # all journeys
    rows = []
    for c in a["cases"]:
        shot = c.get("screenshot")
        rows.append(f'<tr><td><span class="st {c["verdict"]}">{c["verdict"]}</span></td>'
                    f'<td><b style="font-weight:500;color:var(--ink)">{e(c["title"] or c["case_id"])}</b>'
                    f'<div class="mono mute">{e(c["case_id"])}</div></td>'
                    f'<td class=hide-sm>{e(c.get("viewport"))}</td><td class="r hide-sm">{c["duration_s"]:.1f} s</td>'
                    f'<td class=hide-sm>{f"<img class=thumb loading=lazy src={chr(34)}{e(shot)}{chr(34)} alt={chr(34)}{chr(34)}>" if shot else ""}</td></tr>')
    if rows:
        out.append(f'<h2>All journeys ({n})</h2><div class=scroll><table><thead><tr><th>Result</th><th>Journey</th>'
                   f'<th class=hide-sm>Device</th><th class="r hide-sm">Time</th><th class=hide-sm>End screen</th></tr></thead>'
                   f'<tbody>{"".join(rows)}</tbody></table></div>')

    # issues
    if a["issues"]:
        tabs = '<button class=on data-d=all>All</button>' + "".join(
            f'<button data-d={d}>{e(l)} ({dims[d]["issues"]})</button>' for d, l in DIMENSIONS.items() if dims.get(d))
        irows = "".join(
            f'<tr data-d={i["dimension"]}><td><span class="sev {i["severity"]}">{e(i["severity"])}</span></td>'
            f'<td><span style="color:var(--ink)">{e(i["title"])}</span>{" <span class=chip>new</span>" if i.get("new") and a.get("baseline") else ""}'
            f'<div class=mute style="font-size:12.5px">{e(_first(i["message"]))}</div></td>'
            f'<td class="mono hide-sm">{e(i["where"] or "—")}</td><td class="mono hide-sm" style="white-space:nowrap;font-size:11.5px">{e(i["rule"])}</td>'
            f'<td class=r>{i["count"]}</td></tr>'
            for i in a["issues"][:400])
        out.append(f'<h2>Issues ({len(a["issues"])})</h2><div class=tabs id=tabs>{tabs}</div><div class=scroll><table id=issues>'
                   f'<thead><tr><th>Severity</th><th>Issue</th><th class=hide-sm>Where</th><th class=hide-sm>Rule</th><th class=r>Seen</th></tr></thead>'
                   f'<tbody>{irows}</tbody></table></div>')

    if a.get("pages"):
        figs = "".join(
            f'<figure><img loading=lazy src="{e(p.get("screenshot"))}" alt=""><figcaption><span style="color:var(--ink)">{e(p["route"])}</span>'
            f' · {e(p["viewport"])} · {p["a11y"]} a11y'
            f'{" · LCP " + str(round(p["vitals"]["lcp"])) + " ms" if (p.get("vitals") or {}).get("lcp") else ""}</figcaption></figure>'
            for p in a["pages"])
        out.append(f'<h2>Scanned screens ({len(a["pages"])})</h2><div class=gallery>{figs}</div>')
        if cov.get("uncovered") and n:
            out.append(f'<p class=note style="margin-top:12px">Not covered by any journey: <span class=mono>{e(", ".join(cov["uncovered"]))}</span></p>')

    out.append(f'<footer class=foot><span>{foot or ("assay 0.1 · evidence in runs/" + e(run.get("id", "")))} · re-grade with <span class=mono>assay grade</span></span>'
               f'<span>{("duration " + dur + " · ") if dur else ""}AI judge {e(j.get("backend"))}/{e(j.get("model"))}: '
               f'{j.get("calls", 0)} calls, ${j.get("cost_usd", 0):.2f}</span></footer>')
    out.append("""<script>document.querySelectorAll('#tabs button').forEach(b=>b.onclick=()=>{
document.querySelectorAll('#tabs button').forEach(x=>x.classList.toggle('on',x===b));
document.querySelectorAll('#issues tbody tr').forEach(r=>r.hidden=!(b.dataset.d==='all'||r.dataset.d===b.dataset.d))})</script>""")
    return page(f"{title} run report", "".join(out))


def _first(msg: str, n: int = 220) -> str:
    """Merged issues carry one message per occurrence; show the first, trimmed."""
    m = (msg or "").split(" | ")[0]
    return m if len(m) <= n else m[: n - 1] + "…"
