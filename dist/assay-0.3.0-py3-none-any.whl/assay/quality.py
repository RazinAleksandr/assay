"""Quality model: ratings A–E per dimension, the quality gate, baseline diff and app coverage.

Ratings use SonarQube's familiar rule so nobody needs a manual:
  A = no issues (info ignored) · B = ≥1 minor · C = ≥1 major · D = ≥1 critical · E = ≥1 blocker
The gate is three-valued like a case: PASSED / FAILED / INCONCLUSIVE (too many cases could not be
checked — rerun or fix the environment; never ship on it, never blame the product for it).
"""
from __future__ import annotations

import json
from pathlib import Path

from .model import DIMENSIONS, FAIL, INCONCLUSIVE, PASS, SEV_RANK, Issue

RATING_ORDER = "ABCDE"


def rating(issues: list[Issue]) -> str:
    worst = min((SEV_RANK[i.severity] for i in issues if i.severity != "info"), default=None)
    if worst is None:
        return "A"
    return {0: "E", 1: "D", 2: "C", 3: "B"}[worst]


def ratings(issues: list[Issue], only_new: bool = False) -> dict[str, str]:
    out = {}
    for dim in DIMENSIONS:
        sel = [i for i in issues if i.dimension == dim and (i.new or not only_new)]
        out[dim] = rating(sel)
    return out


def load_baseline(path: Path | dict | None) -> dict | None:
    if not path:
        return None
    if isinstance(path, dict):          # a reference analysis fetched from the Assay server
        return path
    path = Path(path)
    f = path / "analysis.json" if path.is_dir() else path
    if not f.exists():
        raise FileNotFoundError(f"baseline analysis not found: {f}")
    return json.loads(f.read_text())


def mark_new(issues: list[Issue], baseline: dict | None) -> None:
    if baseline is None:
        return
    known = {i["fingerprint"] for i in baseline.get("issues", [])}
    for i in issues:
        i.new = i.fingerprint not in known


def case_changes(results: list[dict], baseline: dict | None) -> dict:
    if baseline is None:
        return {}
    prev = {r["case_id"]: r["verdict"] for r in baseline.get("cases", [])}
    reg = [r["case_id"] for r in results if r["verdict"] == FAIL and prev.get(r["case_id"]) != FAIL]
    fixed = [r["case_id"] for r in results if r["verdict"] == PASS and prev.get(r["case_id"]) == FAIL]
    return {"regressions": reg, "fixed": fixed}


KNOWN_BUG = "known-bug"   # tag of a journey that encodes a bug not fixed yet


def gate(cfg: dict, results: list[dict], issues: list[Issue], new_ratings: dict[str, str],
         baseline: dict | None = None) -> dict:
    """`new_code: true` (what `assay ci` sets for pull requests) makes the journey condition look at *new code* only,
    like SonarQube: a journey that already failed on the target branch does not block the change, a journey that
    starts failing does. On a branch (release readiness) every failing journey counts. Issue conditions (`max_new`)
    always count new issues when there is a baseline.
    `first_analysis: true` (a pull request whose target branch has no analysis yet, e.g. the one that connects Assay):
    nothing to compare with, so problems are listed as warnings and block nothing; the target's first analysis
    becomes the reference for the next pull request.
    Journeys tagged `known-bug` are expected failures (like pytest's xfail): they and their issues are listed on every
    analysis but count in no condition. Once the fix lands they pass and guard against the bug coming back."""
    conds = []
    n = len(results)
    known = {r.get("case_id") for r in results if KNOWN_BUG in (r.get("tags") or [])}
    issues = [i for i in issues if not (i.rule == "CASE-FAIL" and i.sources and set(i.sources) <= known)]
    results_all, results = results, [r for r in results if not (known and r.get("case_id") in known)]
    n_fail = sum(r["verdict"] == FAIL for r in results)
    n_inc = sum(r["verdict"] == INCONCLUSIVE for r in results_all)

    if cfg.get("fail_on_case_fail", True):
        if baseline is not None and cfg.get("new_code", False):
            prev = {r["case_id"]: r["verdict"] for r in baseline.get("cases", [])}
            newly = sum(1 for r in results if r["verdict"] == FAIL and prev.get(r["case_id"]) != FAIL)
            conds.append({"name": "New failed journeys", "actual": newly, "op": "=", "threshold": 0, "ok": newly == 0})
        else:
            conds.append({"name": "Failed journeys", "actual": n_fail, "op": "=", "threshold": 0, "ok": n_fail == 0})
    for sev, limit in (cfg.get("max_new") or {}).items():
        cnt = sum(1 for i in issues if i.new and i.severity == sev)
        conds.append({"name": f"New {sev} issues", "actual": cnt, "op": "≤", "threshold": limit, "ok": cnt <= limit})
    for dim, worst in (cfg.get("min_rating") or {}).items():
        r = new_ratings.get(dim, "A")
        conds.append({"name": f"{DIMENSIONS.get(dim, dim)} rating (new)", "actual": r, "op": "≤", "threshold": worst,
                      "ok": RATING_ORDER.index(r) <= RATING_ORDER.index(worst)})
    share = (n_inc / n) if n else 0.0
    max_inc = float(cfg.get("max_inconclusive", 0.2))
    inconclusive = n > 0 and share > max_inc
    conds.append({"name": "Inconclusive journeys", "actual": f"{share:.0%}", "op": "≤", "threshold": f"{max_inc:.0%}",
                  "ok": not inconclusive, "soft": True})
    if cfg.get("first_analysis"):
        for c in conds:
            c["soft"] = True
    hard_fail = any(not c["ok"] for c in conds if not c.get("soft"))
    status = "FAILED" if hard_fail else ("INCONCLUSIVE" if inconclusive else "PASSED")
    return {"status": status, "conditions": conds, **({"first_analysis": True} if cfg.get("first_analysis") else {})}


def coverage(scan_routes: list[str], case_routes: list[str]) -> dict:
    disc = sorted(set(scan_routes))
    hit = sorted(set(case_routes) & set(disc))
    return {"discovered": disc, "covered": hit, "uncovered": sorted(set(disc) - set(hit)),
            "ratio": round(len(hit) / len(disc), 3) if disc else None}
