"""Portfolio: one page over many apps (SonarQube's portfolio view) — gate, ratings, journeys, issues."""
from __future__ import annotations

import json
import os
from pathlib import Path

from .model import DIMENSIONS
from .report import GATE_ICON, RATING_COLOR, SEV_ICON
from .theme import CSS, e as _e


def latest_analysis(project: Path, run_id: str | None = None) -> Path | None:
    runs = project / "runs"
    if run_id and (runs / run_id / "analysis.json").exists():
        return runs / run_id / "analysis.json"
    cands = [p for p in runs.glob("*/analysis.json") if not p.parent.name.startswith(("dev", "doctor", "bench"))]
    return max(cands, key=lambda p: p.stat().st_mtime) if cands else None


def build(projects: list[Path], out: Path, run_id: str | None = None) -> dict:
    rows = []
    for proj in projects:
        f = latest_analysis(proj, run_id)
        if not f:
            continue
        a = json.loads(f.read_text())
        a["_report"] = os.path.relpath(f.parent / "report.html", out.parent)
        rows.append(a)
    parts = [f"<!doctype html><html lang=en><head><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'>"
             f"<title>Assay portfolio</title><style>{CSS}"
             ".wrap{max-width:1120px;margin:0 auto}header{border-bottom:2px solid var(--ink);padding-bottom:10px;margin-bottom:18px}"
             ".kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:0;border-block:1px solid var(--rule)}"
             ".kpi{padding:12px 14px 12px 0}.kpi b{display:block;font-size:24px;font-weight:600;color:var(--ink)}.kpi span{font-size:12px;color:var(--mute)}"
             ".card{border-bottom:1px solid var(--rule);padding:14px 0}.sub{font-size:12px;color:var(--mute)}"
             ".letter{display:grid;place-items:center;color:#fff;font-weight:600;border-radius:2px}"
             ".gate{font-size:11.5px;font-weight:600;letter-spacing:.04em}.gate.PASSED{color:var(--pass)}.gate.FAILED{color:var(--fail)}.gate.INCONCLUSIVE{color:var(--inc)}"
             ".app{display:grid;grid-template-columns:1.3fr 2fr 1fr;gap:16px;align-items:center}"
             ".mini{display:flex;gap:6px;flex-wrap:wrap}.mini .letter{width:30px;height:30px;font-size:14px}"
             ".mini div{text-align:center;font-size:10px;color:var(--mute)}"
             "@media(max-width:760px){.app{grid-template-columns:1fr}}</style></head><body><div class=wrap>"
             "<header><div><h1>Portfolio — quality of running apps</h1><div class=sub>latest gate per app</div></div></header>"]
    tot = {"cases": 0, "PASS": 0, "FAIL": 0, "INCONCLUSIVE": 0, "issues": 0, "pages": 0}
    for a in rows:
        s = a["summary"]
        for k in ("cases", "PASS", "FAIL", "INCONCLUSIVE", "issues"):
            tot[k] += s[k]
        tot["pages"] += s["pages_scanned"]
    parts.append(f"<div class=kpis><div class='card kpi'><b>{len(rows)}</b><span>apps</span></div>"
                 f"<div class='card kpi'><b>{tot['cases']}</b><span>journeys · {tot['PASS']} pass · {tot['FAIL']} fail · {tot['INCONCLUSIVE']} inconclusive</span></div>"
                 f"<div class='card kpi'><b>{tot['pages']}</b><span>screens scanned</span></div>"
                 f"<div class='card kpi'><b>{tot['issues']}</b><span>issues found</span></div></div><h2>Apps</h2>")
    for a in rows:
        s, g = a["summary"], a["gate"]
        r = a.get("ratings_new") or a["ratings"]
        mini = "".join(f"<div><span class=letter style='background:{RATING_COLOR[r[d]]};display:grid;place-items:center;color:#fff;border-radius:2px;font-weight:600'>{r[d]}</span>{_e(l.split(' ')[0])}</div>"
                       for d, l in DIMENSIONS.items())
        bs = s.get("by_severity", {})
        cov = a.get("coverage") or {}
        parts.append(f"<div class='card app' style='margin-bottom:12px'><div><b style='font-size:16px'>{_e(a['app'].get('title') or a['app']['name'])}</b>"
                     f"<div class=sub><a href='{_e(a['_report'])}'>report</a> · run {_e(a['run'].get('id', ''))}</div>"
                     f"<div class='gate {g['status']}' style='font-size:13px;padding:4px 10px;margin-top:8px;display:inline-flex'>{GATE_ICON[g['status']]} {g['status']}</div></div>"
                     f"<div class=mini>{mini}</div>"
                     f"<div class=sub><b style='color:var(--ink)'>{s['PASS']}/{s['cases']}</b> journeys pass<br>"
                     + " ".join(f"{SEV_ICON[k]}{bs.get(k, 0)}" for k in ("blocker", "critical", "major", "minor"))
                     + f"<br>{s['pages_scanned']} screens" + (f" · coverage {cov['ratio']:.0%}" if cov.get("ratio") is not None else "")
                     + "</div></div>")
    parts.append("</div></body></html>")
    out.write_text("".join(parts))
    return {"apps": len(rows), **tot}
